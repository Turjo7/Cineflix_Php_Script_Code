<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('settings', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('url');
            $table->string('logo');
            $table->string('textlogo');
            $table->string('logo_type');
            $table->string('site_title');
            $table->string('email');
            $table->string('copyright');
            $table->integer('display_ads');
            $table->integer('watch');
            $table->text('analytics');
            $table->text('keywords');
            $table->text('description');
            $table->string('facebook');
            $table->string('twitter');
            $table->string('instagram');
            $table->string('pinterest');
            $table->text('faq');
            $table->text('terms');
            $table->text('privacy');
            $table->text('contact');
            $table->string('tmdb');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('settings');
    }
}
