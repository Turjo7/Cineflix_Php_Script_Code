<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTvShowCreditsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tv_show_credits', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('tvshow_id')->unsigned()->index();
            $table->string('name')->nullable();
            $table->string('image')->nullable();
            $table->string('character')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tv_show_credits');
    }
}
