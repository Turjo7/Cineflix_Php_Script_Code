<?php

use Illuminate\Database\Seeder;

class PagesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\Page::insert([

            'faq'=>'Lorem ipsum dolorem set',
            'terms'=>'Lorem ipsum dolorem set',
            'privacy'=>'Lorem ipsum dolorem set',
            'contact'=>'Lorem ipsum dolorem set'

        ]);
    }
}
