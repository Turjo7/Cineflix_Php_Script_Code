<?php

use Illuminate\Database\Seeder;

class AddAdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\User::insert([

            'name'=>'admin',
            'role_id'=>'1',
            'email'=>'admin@email.com',
            'password'=>bcrypt('asdfghjkl'),
            'created_at'=>\Carbon\Carbon::now(),
            'updated_at'=>\Carbon\Carbon::now(),

        ]);
    }
}
