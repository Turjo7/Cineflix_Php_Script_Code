<?php

use Illuminate\Database\Seeder;

class SettingsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\Setting::insert([

            'url'=>'website.com',
            'logo'=>'/cineflix-logo.png',
            'textlogo'=>'cineflix',
            'logo_type'=>'text',
            'site_title'=>'CINEFLIX - Watch Movies Online',
            'email'=>'support@website.com',
            'copyright'=>'© 2019 CINEFLIX - Watch Movies Online',
            'display_ads'=>'1',
            'watch'=>'0',
            'analytics'=>'...',
            'keywords'=>'watch, movies, online, cineflix, online movies',
            'description'=>'Watch online movies on Cineflix, your favorite streaming platform!',
            'facebook'=>'https://facebook.com',
            'twitter'=>'https://twitter.com',
            'instagram'=>'https://instagram.com',
            'pinterest'=>'https://pinterest.com',
            'faq'=>'This is the FAQ page',
            'terms'=>'This is the Terms and Conditions page',
            'privacy'=>'This is the Privacy page',
            'contact'=>'This is the Contact page',
            'tmdb'=>'3d0aae1ee7316026b322dde67dd772c7'

        ]);
    }
}
