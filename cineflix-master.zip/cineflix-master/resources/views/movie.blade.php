@extends('layouts.movie')

@section('content')

    <!-- start Main Content (Media Page Section) -->

    <div id="tm-media-section" class="uk-block uk-block-small">

        @if($setting->display_ads == 1)
        <div class="uk-grid">
            <div class="uk-width-1-1">
                <div class="uk-width-medium-1-2 uk-container-center">
                    {!! $ad->large !!}
                </div>
            </div>
        </div>
        @endif

        <div class="uk-container uk-container-center uk-width-8-10 main-bg">

            <div class="custom-bg"></div>

            <div class="media-container  uk-container-center">
                <a class="uk-button uk-button-large uk-button-link uk-text-muted" href="{{route('homepage')}}"><i class=" uk-icon-arrow-left uk-margin-small-right"></i> Back</a>
            </div>

            <div class="uk-grid">
                <div class="uk-width-medium-3-10">
                    <div  class="media-cover">
                        @if($movie->imported == 1)
                        <img src="https://image.tmdb.org/t/p/w500{{$movie->poster}}" alt="Image" class="uk-scrollspy-inview uk-animation-fade">
                        @else
                        <img src="../img/{{$movie->poster}}" alt="Image" class="uk-scrollspy-inview uk-animation-fade">
                        @endif
                    </div>
                    <button class="uk-button uk-button-primary uk-button-large uk-width-1-1 uk-margin-top" data-uk-modal="{target:'#modalwatch'}"><i class="uk-icon-television uk-margin-small-right"></i> Watch Now</button>
                    @if(Auth::check())

                        @if($isInList == 1)

                            <form class="uk-form" method="post" action="{{action('MovieFavorites@destroy')}}">
                                @csrf
                                <input type="hidden" name="user_id" value="{{$user->id}}">
                                <input type="hidden" name="movie_slug" value="{{$movie->slug}}">

                                <button type="submit" class="uk-button uk-button-link uk-text-muted uk-button-large uk-width-1-1 uk-margin-top"><i class="uk-icon-remove uk-margin-small-right"></i> Remove from my list</button>

                            </form>

                        @else

                            <form class="uk-form" method="post" action="{{action('MovieFavorites@store')}}">
                                @csrf
                                <input type="hidden" name="user_id" value="{{$user->id}}">
                                <input type="hidden" name="movie_title" value="{{$movie->title}}">
                                <input type="hidden" name="movie_slug" value="{{$movie->slug}}">
                                <input type="hidden" name="movie_poster" value="{{$movie->poster}}">

                                <button type="submit" class="uk-button uk-button-link uk-text-muted uk-button-large uk-width-1-1 uk-margin-top"><i class="uk-icon-heart uk-margin-small-right"></i> Add to Favourites</button>
                            </form>

                        @endif

                    @else
                        <a class="uk-button uk-button-link uk-text-muted uk-button-large uk-width-1-1 uk-margin-top" href="{{route('login')}}"><i class="uk-icon-heart uk-margin-small-right"></i> Add to Favourites</a>
                    @endif
                </div>
                <div id="modalwatch" class="uk-modal">
                    <div class="uk-modal-dialog">
                        <div class="uk-modal-header"><h3>Watch Online {{$movie->title}}</h3></div>
                        @if($setting->watch == 0)

                            @foreach($movie->videos as $video)
                                <iframe src="{{$video->name}}?autoplay=0&amp;controls=0&amp;showinfo=0&amp;rel=0&amp;loop=1&amp;modestbranding=1&amp;wmode=transparent" width="560" height="315" frameborder="0" allowfullscreen=""></iframe>
                            @endforeach

                        @else

                            @if(Auth::check())

                                @foreach($movie->videos as $video)
                                    <iframe src="{{$video->name}}?autoplay=0&amp;controls=0&amp;showinfo=0&amp;rel=0&amp;loop=1&amp;modestbranding=1&amp;wmode=transparent" width="560" height="315" frameborder="0" allowfullscreen=""></iframe>
                                @endforeach

                            @else

                                <p>You have to be registered to watch online movie</p>

                            @endif

                        @endif

                    </div>
                </div>
                <div class="uk-width-medium-7-10">

                    @if(Session::has('status'))

                        <div class="uk-grid">
                            <div class="uk-width-1-1">
                                <div class="uk-container-center">
                                    <div class="uk-alert" data-uk-alert>
                                        <a href="" class="uk-alert-close uk-close"></a>
                                        <p>{{session('status')}}</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                    @endif

                        @if(Session::has('status-warning'))

                            <div class="uk-grid">
                                <div class="uk-width-1-1">
                                    <div class="uk-container-center">
                                        <div class="uk-alert-warning" data-uk-alert>
                                            <a href="" class="uk-alert-close uk-close"></a>
                                            <p>{{session('status-warning')}}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        @endif

                    <div class="">
                        <ul class="uk-tab uk-tab-grid " data-uk-switcher="{connect:'#media-tabs'}">
                            <li class="uk-width-medium-1-3 uk-active"><a href="#">Description</a></li>
                            <li class="uk-width-medium-1-3"><a href="#">Reviews</a></li>
                            <li class="uk-width-medium-1-3"><a href="#">Trailer</a></li>
                            <li class="uk-tab-responsive uk-active uk-hidden" aria-haspopup="true" aria-expanded="false"><a>Active</a><div class="uk-dropdown uk-dropdown-small uk-dropdown-up"><ul class="uk-nav uk-nav-dropdown"></ul><div></div></div></li></ul>
                    </div>

                    <ul id="media-tabs" class="uk-switcher">

                        <!--     start Tab Panel 1 (Reviews Sections) -->

                        <li>
                            <h2 class="uk-text-contrast uk-margin-large-top">{{$movie->title}} </h2>
                            <ul class="uk-subnav uk-subnav-line">
                                <li ><i class="uk-icon-star uk-margin-small-right"></i> {{$movie->vote_average}}</li>
                                <li><i class="uk-icon-clock-o uk-margin-small-right"></i> {{$movie->runtime}} Mins</li>
                                <li>Release Date: {{$movie->release_date}}</li>
                            </ul>
                            <hr>
                            <p class="uk-text-muted uk-h4">{{$movie->overview}}</p>
                            <dl class="uk-description-list-horizontal uk-margin-top">

                                <dt>Genres</dt>
                                <dd>
                                    <ul class="uk-subnav ">
                                        @foreach($movie->categories as $category)
                                            <li>{{ucfirst($category->name)}}</li>
                                        @endforeach
                                    </ul>
                                </dd>

                                <dt>Credits</dt>
                                <dd>
                                    <ul class="uk-subnav ">
                                        @foreach($credits as $credit)
                                            <li>{{ucfirst($credit->name)}}</li>
                                        @endforeach
                                    </ul>
                                </dd>

                                <dt>Budget</dt>
                                <dd>
                                    {{number_format($movie->budget)}} $
                                </dd>

                                <dt>Revenue</dt>
                                <dd>
                                    {{number_format($movie->revenue)}} $
                                </dd>
                            </dl>

                        </li>

                        <!--    ./ Tab Panel 1  -->

                        <!--     start Tab Panel 2  (Reviews Section) -->

                        <li>
                            <div class="uk-margin-small-top">
                                <h3 class="uk-text-contrast uk-margin-top">Post a Review</h3>
                                @if(!Auth::check())
                                <div class="uk-alert uk-alert-warning" data-uk-alert="">
                                    <a href="" class="uk-alert-close uk-close"></a>
                                    <p><i class="uk-icon-exclamation-triangle uk-margin-small-right "></i> Please <a class="uk-text-contrast" href="{{route('login')}}"> Log in</a> or Sign up to post reviews quicker.</p>
                                </div>
                                @endif
                                @if(Auth::check())

                                <form class="uk-form uk-margin-bottom" method="post" action="{{action('ReviewsController@store')}}">
                                    @csrf
                                    <input type="hidden" name="author" value="{{$user->name}}">
                                    <input type="hidden" name="movie_id" value="{{$movie->id}}">
                                    <div class="uk-form-row">
                                        <textarea name="body" class="uk-width-1-1" cols="30" rows="5" placeholder="Type your review here..." required></textarea>
                                    </div>
                                    <div class="uk-form-row">
                                        <button type="submit" class="uk-button uk-button-large uk-button-success uk-float-right">Post</button>
                                    </div>
                                </form>
                                @endif
                            </div>

                            <div  class="uk-scrollable-box uk-responsive-width " data-simplebar-direction="vertical">

                                @if(count($reviews) > 0)

                                    @foreach($reviews as $review)
                                    <ul class="uk-comment-list uk-margin-top" >
                                        <li>
                                            <article class="uk-comment uk-panel uk-panel-space uk-panel-box-secondary">
                                                <header class="uk-comment-header">
                                                    <img class="uk-comment-avatar uk-border-circle" src="assets/img/avatar3.jpg" width="50" height="50" alt="">
                                                    <h4 class="uk-comment-title">{{$review->author}}</h4>
                                                    <div class="uk-comment-meta">{{$review->created_at->diffForHumans()}}</div>
                                                </header>
                                                <div class="uk-comment-body">
                                                    <p>{{$review->body}}</p>
                                                </div>
                                            </article>
                                        </li>
                                    </ul>
                                    @endforeach
                                @else

                                <h2>No reviews yet!</h2>

                                @endif

                                    <div class="space"></div>

                                    <div class="uk-width-medium-1-2 uk-container-center">
                                        {{$reviews->links('vendor.pagination.default')}}
                                    </div>
                            </div>
                        </li>
                        <!--     ./ Tab Panel 2  -->


                        <!--     start Tab Panel 3 (Trailer Section)  -->

                        <li>
                            <div class="uk-cover uk-margin-top" style="height: 400px;">
                                <iframe data-uk-cover src="{{$movie->trailer}}?autoplay=0&amp;controls=0&amp;showinfo=0&amp;rel=0&amp;loop=1&amp;modestbranding=1&amp;wmode=transparent" width="560" height="315" frameborder="0" allowfullscreen=""></iframe>
                            </div>
                        </li>

                        <!--     ./ Tab Panel 3  -->


                    </ul>

                        <div class="space"></div>

                        @if($setting->display_ads == 1)

                            <div class="uk-width-1-2 uk-container-center">
                                {!! $ad->small !!}
                            </div>


                        @endif

                </div>
            </div>
        </div>
    </div>

    </div>

    <!-- ./ Main Content (Media Page Section) -->

@endsection