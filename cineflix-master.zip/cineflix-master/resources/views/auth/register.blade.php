@extends('layouts.auth')

@section('content')

<div class="uk-overlay uk-text-center uk-vertical-align uk-height-1-1">
    <img class="uk-animation-fade tm-bg-cover" src="img/bg.jpg" width="100%" height="100%" alt="">
    <div class="uk-vertical-align  uk-overlay-panel uk-overlay-background authbg">
        <div class=" uk-vertical-align-middle uk-text-center  uk-width-medium-3-10 uk-width-large-2-10 uk-container-center">

            <div class="uk-margin-large-bottom  uk-animation-reverse uk-animation-scale uk-animation-hover">
                <a class="uk-hidden-small" href="{{route('homepage')}}"><i class="uk-icon-small uk-text-primary uk-margin-small-right uk-icon-play-circle"></i>

                    @if($setting->logo_type == 'text')

                        <span class="logLogo">{{$setting->textlogo}}</span>

                    @else

                        <img src="img{{$setting->textlogo}}">

                    @endif

                </a>
            </div>
            <form  class="uk-form" method="POST" action="{{ route('register') }}">
                @csrf
                <h2 class="uk-margin-large-bottom uk-text-muted">Sign up</h2>

                <div class="uk-form-row">
                    <div class="uk-form-icon uk-form-icon-flip uk-width-1-1">
                        <input placeholder="Username" id="name" type="text" class="uk-width-1-1{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>

                        @if ($errors->has('name'))
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                        @endif
                        <i class="uk-icon-user"></i>
                    </div>
                </div>
                <div class="uk-form-row">
                    <div class="uk-form-icon uk-form-icon-flip uk-width-1-1">
                        <input placeholder="Email" id="email" type="email" class="uk-width-1-1{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" required autocomplete="email">

                        @if ($errors->has('email'))
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                        @endif
                        <i class="uk-icon-envelope"></i>
                    </div>
                </div>
                <div class="uk-form-row">
                    <div class="uk-form-icon uk-form-icon-flip uk-width-1-1" >
                        <input placeholder="Password" id="password" type="password" class="uk-width-1-1{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required autocomplete="new-password">

                        @if ($errors->has('password'))
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                        @endif
                        <i class="uk-icon-lock "></i>
                    </div>
                </div>
                <div class="uk-form-row">
                    <div class="uk-form-icon uk-form-icon-flip uk-width-1-1" >
                        <input placeholder="Confirm Pasword" id="password-confirm" type="password" class="uk-width-1-1" name="password_confirmation" required autocomplete="new-password">
                        <i class="uk-icon-lock "></i>
                    </div>
                </div>
                <div class="uk-form-row uk-text-small">
                    <label class="uk-float-left">
                        <input type="checkbox" required> I agree to the Terms &amp; Conditions
                    </label>
                </div>
                <div class="uk-form-row">
                    <button type="submit" class="uk-width-1-1 uk-button uk-button-primary uk-button-large">
                        {{ __('Register') }}
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>
<!-- ./ Main Content  -->

@endsection
