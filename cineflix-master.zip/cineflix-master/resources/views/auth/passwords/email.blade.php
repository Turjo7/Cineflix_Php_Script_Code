@extends('layouts.auth')

@section('content')

<!--     Start Main Content  -->
<div class="uk-overlay uk-text-center uk-vertical-align uk-height-1-1">
    <img class="uk-animation-fade tm-bg-cover" src="../img/bg.jpg" width="100%" height="100%" alt="">
    <div class="uk-vertical-align  uk-overlay-panel uk-overlay-background authbg">
        <div class=" uk-vertical-align-middle uk-text-center  uk-width-medium-3-10 uk-width-large-2-10 uk-container-center">

            <div class="uk-margin-large-bottom  uk-animation-reverse uk-animation-scale uk-animation-hover">
                <h2><a class="uk-hidden-small" href="{{route('homepage')}}"><i class="uk-icon-small uk-text-primary uk-margin-small-right uk-icon-play-circle"></i>

                        @if($setting->logo_type == 'text')

                            <span class="logLogo">{{$setting->textlogo}}</span>

                        @else

                            <img src="img{{$setting->textlogo}}">

                        @endif

                    </a></h2>
            </div>

            @if(Session::has('status'))

                <div class="uk-grid">
                    <div class="uk-width-1-1">
                        <div class="uk-alert uk-alert-success" data-uk-alert>
                            <a href="" class="uk-alert-close uk-close"></a>
                            <p>{{session('status')}}</p>
                        </div>
                    </div>
                </div>

            @endif

            <form  class="uk-form" method="POST" action="{{ route('password.email') }}">
                @csrf
                <h2 class="uk-margin-large-bottom uk-text-muted">Reset Password</h2>
                <div class="uk-form-row">
                    <div class="uk-form-icon uk-form-icon-flip uk-width-1-1">

                        <input id="email" type="email" class="uk-width-1-1{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
                        <i class="uk-icon-user"></i>
                        @if ($errors->has('email'))
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                        @endif
                    </div>
                </div>
                <div class="uk-form-row">
                    <button type="submit" class="uk-width-1-1 uk-button uk-button-success uk-button-large">
                        {{ __('Send Password Reset Link') }}
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>
<!-- ./ Main Content  -->
@endsection
