@extends('layouts.default')

@section('content')

    <!--     start Main Content Section   -->

    <div class="uk-container uk-container-center uk-margin-large-top uk-margin-large-bottom">

        <h2>My Account</h2>

        <hr>

        <div class="uk-grid">

            <div id="tm-right-section" class="uk-width-6-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">

                <h3 class="inline">My Favorites Tv Shows</h3>

                <div class="uk-grid-width-small-1-3 uk-grid-width-medium-1-4 uk-grid-width-large-1-6" data-uk-grid="{gutter: 20}">

                    @foreach($favoriteTvShows as $tvshow)

                        <div>
                            <div class="uk-overlay uk-overlay-hover">
                                <img src="https://image.tmdb.org/t/p/w500{{$tvshow->tvshow_poster}}" alt="Image" >
                                <div class="uk-overlay-panel uk-overlay-fade uk-overlay-background  uk-overlay-icon"></div>
                                <a class="uk-position-cover" href="{{route('tvshow_detail', $tvshow->tvshow_slug)}}"></a>
                            </div>
                            <div class="uk-panel uk-container-center">

                                <h6 class="uk-panel-title">{{str_limit($tvshow->tvshow_title, 9)}}</h6>

                            </div>
                        </div>

                    @endforeach

                </div>

                <div class="space"></div>

                <div class="uk-width-medium-1-2 uk-container-center">
                    {{$favoriteTvShows->links('vendor.pagination.default')}}
                </div>

                <h3 class="inline">My Favorites Movies</h3>

                <div class="uk-grid-width-small-1-3 uk-grid-width-medium-1-4 uk-grid-width-large-1-6" data-uk-grid="{gutter: 20}">

                    @foreach($favoriteMovies as $movie)

                        <div>
                            <div class="uk-overlay uk-overlay-hover">
                                <img src="https://image.tmdb.org/t/p/w500{{$movie->movie_poster}}" alt="Image" >
                                <div class="uk-overlay-panel uk-overlay-fade uk-overlay-background  uk-overlay-icon"></div>
                                <a class="uk-position-cover" href="{{route('movie_detail', $movie->movie_slug)}}"></a>
                            </div>
                            <div class="uk-panel uk-container-center">

                                <h6 class="uk-panel-title">{{str_limit($movie->movie_title, 9)}}</h6>

                            </div>
                        </div>

                    @endforeach

                </div>

                <div class="space"></div>

                <div class="uk-width-medium-1-2 uk-container-center">
                    {{$favoriteMovies->links('vendor.pagination.default')}}
                </div>

            </div>

            <div class="uk-grid-4-10">
                <h3>Account Settings</h3>
                <hr>

                @include('includes.errors')

                @if(Session::has('status'))

                    <div class="uk-grid">
                        <div class="uk-width-1-1">
                            <div class="uk-alert uk-alert-success" data-uk-alert>
                                <a href="" class="uk-alert-close uk-close"></a>
                                <p>{{session('status')}}</p>
                            </div>
                        </div>
                    </div>

                @endif

                @if(Session::has('status-warning'))

                    <div class="uk-grid">
                        <div class="uk-width-1-1">
                            <div class="uk-alert uk-alert-warning" data-uk-alert>
                                <a href="" class="uk-alert-close uk-close"></a>
                                <p>{{session('status-warning')}}</p>
                            </div>
                        </div>
                    </div>

                @endif

                <div class="space"></div>

                <div class="uk-panel">
                    <div class="uk-panel-badge uk-badge">Update User/Email</div>
                    <h3 class="uk-panel-title"></h3>
                    <form class="uk-form" method="post" action="{{action('HomeController@updateUserEmail')}}">
                        @csrf
                        <div class="uk-form-row">

                            <label class="uk-form-label uk-width-1-1" for="">Username:</label>
                            <input type="text" placeholder="Your username..." class="uk-width-1-1" name="name" value="{{$user->name}}">

                        </div>
                        <div class="uk-form-row">

                            <label class="uk-form-label uk-width-1-1" for="">Email:</label>
                            <input type="email" placeholder="Your email..." class="uk-width-1-1" name="email" value="{{$user->email}}">

                        </div>

                        <div class="uk-form-row">
                            <button class="uk-button uk-button-danger uk-float-left" type="submit">Save changes</button>
                        </div>

                    </form>
                </div>

                <div class="uk-panel">
                    <div class="uk-panel-badge uk-badge">Change Password</div>
                    <h3 class="uk-panel-title"></h3>
                    <form class="uk-form" method="post" action="{{action('HomeController@updatePassword')}}">
                        @csrf
                        <div class="uk-form-row">

                            <label class="uk-form-label uk-width-1-1" for="">Current password:</label>
                            <input type="password" placeholder="Current password..." class="uk-width-1-1" name="current-password">

                        </div>
                        <div class="uk-form-row">

                            <label class="uk-form-label uk-width-1-1" for="">New Password:</label>
                            <input type="password" placeholder="New Password..." class="uk-width-1-1" name="password">

                        </div>

                        <div class="uk-form-row">

                            <label class="uk-form-label uk-width-1-1" for="">Confirm Password:</label>
                            <input type="password" placeholder="Confirm Password..." class="uk-width-1-1" name="confirm-password">

                        </div>

                        <div class="uk-form-row">
                            <button class="uk-button uk-button-danger uk-float-left" type="submit">Update Password</button>
                        </div>

                    </form>
                </div>

            </div>

        </div>
    </div>

    <!--     ./ Main Content Section   -->

@endsection
