<!DOCTYPE html>
<html lang="en-gb" dir="ltr" class="uk-height-1-1">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{$setting->site_title}}</title>
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="assets/img/x-icon">
    <link rel="apple-touch-icon-precomposed" href="assets/img/apple-touch-icon.png">

    <!--     Include UIKit CSS   -->

    <!--     Theme CSS   -->
    <link rel="stylesheet" href="{{asset('css/all.css')}}">

    <link rel="stylesheet" href="{{asset('css/app.css')}}">

</head>

<body  class="uk-height-1-1" cz-shortcut-listen="true">



<!--     start Top Navbar   -->

<div class="tm-navbar tm-navbar-overlay tm-navbar-transparent tm-navbar-contrast">
    <nav class="uk-navbar uk-margin-top">
        <div class="uk-container-center uk-container" style="background-color: #020202">
            <div class="uk-navbar-flip">
                <a href="#offcanvas" class="uk-navbar-toggle uk-icon-medium" data-uk-offcanvas=""></a>
            </div>
        </div>
    </nav>
</div>

<!--     ./ Top Navbar   -->


@yield('content')

<!-- ./ Offcanvas Menu  -->

<div id="offcanvas" class="uk-offcanvas">
    <div class="uk-offcanvas-bar">
        <div class="uk-panel">
            <form class="uk-search"  method="get" action="/search">
                <input class="uk-search-field" type="search" placeholder="Search..." name="q">
            </form>
            <div class="uk-button-group">
                @if(Auth::guest())
                    <a class="uk-button uk-button-link uk-button-large uk-text-muted" href="{{url('/register')}}">Sign up</a>
                    <a class="uk-button uk-button-success uk-button-large uk-margin-left" href="{{url('/login')}}"><i class="uk-icon-lock uk-margin-small-right"></i> Log in</a>
                @else
                    <a class="uk-button uk-button-link uk-button-large" href="{{route('logout')}}">Logout</a>
                    <a class="uk-button uk-button-success uk-button-large uk-margin-left" href="{{route('home')}}"><i class="uk-icon-lock uk-margin-small-right"></i> Dashboard</a>
                @endif

            </div>
        </div>
        <ul class="uk-nav uk-nav-offcanvas uk-nav-parent-icon" data-uk-nav>
            <li class="uk-active">
                <a href="{{route('homepage')}}">Home</a>
            </li>
            <li>
                <a href="{{route('movies')}}">Movies</a>
            </li>
            <li>
                <a href="">TV Shows</a>
            </li>
            <li class="uk-parent">
                <a href="#">Genre</a>
                <ul class="uk-nav-sub">
                    @foreach($categories as $category)
                        <li><a href="{{route('category', $category->name)}}">{{ucfirst($category->name)}}</a></li>
                    @endforeach
                </ul>
            </li>
            <li class="uk-nav-divider"></li>
            <li class="uk-nav-header">Pages</li>
            <li><a href="{{route('faq')}}"> FAQ's</a></li>
            <li><a href="{{route('terms')}}"> Terms & Conditions</a></li>
            <li><a href="{{route('privacy')}}"> Privacy Policy</a></li>
            <li><a href="{{route('contact')}}"> Contact Us</a></li>
        </ul>
        <div class="uk-panel uk-text-center">
            <ul class="uk-subnav">
                <li><a target="_blank" href="{{$setting->facebook}}" class="uk-icon-hover uk-icon-medium uk-icon-facebook-square"></a></li>
                <li><a target="_blank" href="{{$setting->twitter}}" class="uk-icon-hover uk-icon-medium uk-icon-twitter"></a></li>
                <li><a target="_blank" href="{{$setting->instagram}}" class="uk-icon-hover uk-icon-medium uk-icon-instagram"></a></li>
                <li><a target="_blank" href="{{$setting->pinterest}}" class="uk-icon-hover uk-icon-medium uk-icon-pinterest"></a></li>
            </ul>
        </div>
    </div>
</div>

<!--     ./ Offcanvas Menu  -->

<!--   Include JS  -->

<script src="{{asset('js/all.js')}}"></script>

</body>
</html