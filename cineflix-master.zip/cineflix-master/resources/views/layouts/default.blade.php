<!DOCTYPE html>
<html lang="en-gb" dir="ltr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{$setting->site_title}}</title>
    <meta name="description" content="{{$setting->description}}">
    <meta name="keywords" content="{{$setting->keywords}}">
    <link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon.png">
    <!--     Include UIKit CSS   -->
    <link rel="stylesheet" href="{{asset('css/app.css')}}">
    <!--     Theme CSS   -->
    <link rel="stylesheet" href="{{asset('css/all.css')}}">
</head>
<body>

<!--     start Header Section   -->

<nav id="tm-topbar" class=" uk-navbar uk-contrast ">
    <div class="uk-container uk-container-center ">
        <ul class="uk-navbar-nav uk-hidden-small">
            <li>
                <a target="_blank" href="{{$setting->facebook}}"><i class="uk-icon-facebook-square uk-icon-small"></i></a>
            </li>
            <li>
                <a target="_blank" href="{{$setting->twitter}}"><i class="uk-icon-twitter-square uk-icon-small"></i></a>
            </li>

            <li>
                <a target="_blank" href="{{$setting->instagram}}"><i class="uk-icon-instagram uk-icon-small"></i></a>
            </li>
            <li>
                <a target="_blank" href="{{$setting->pinterest}}"><i class="uk-icon-pinterest uk-icon-small"></i></a>
            </li>

        </ul>
        <div class="uk-navbar-flip">
            <ul class="uk-navbar-nav uk-hidden-small">
                <li>
                    <a href="{{route('faq')}}">FAQ's</a>
                </li>
                <li>
                    <a href="{{route('terms')}}">Terms & Conditions</a>
                </li>

                <li>
                    <a href="{{route('privacy')}}">Privacy Policy</a>
                </li>
                <li>
                    <a href="{{route('contact')}}">Contact Us</a>
                </li>
            </ul>
        </div>
    </div>

</nav>
<nav id="tm-header" class="uk-navbar ">
    <div class="uk-container uk-container-center ">
        <a class="uk-navbar-brand uk-hidden-small" href="{{route('homepage')}}"><i class="uk-icon-small uk-text-primary uk-margin-small-right uk-icon-play-circle"></i>

            @if($setting->logo_type == 'text')

                {{$setting->textlogo}}

                @else

                <img src="img{{$setting->textlogo}}">

            @endif

        </a>


        <div class="uk-navbar-flip uk-hidden-small">
            <div class="uk-button-group">
                @if(Auth::guest())
                <a class="uk-button uk-button-link uk-button-large" href="{{url('/register')}}">Sign up</a>
                <a class="uk-button uk-button-success uk-button-large uk-margin-left" href="{{url('/login')}}"><i class="uk-icon-lock uk-margin-small-right"></i> Log in</a>
                @else
                    <a class="uk-button uk-button-link uk-button-large" href="{{route('logout')}}">Logout</a>
                    <a class="uk-button uk-button-success uk-button-large uk-margin-left" href="{{route('home')}}"><i class="uk-icon-lock uk-margin-small-right"></i> Dashboard</a>
                @endif
            </div>
        </div>
        <a href="#offcanvas" class="uk-navbar-toggle uk-visible-small uk-icon-medium" data-uk-offcanvas></a>
        <div class="uk-navbar-flip uk-visible-small">
            <a href="#offcanvas" class="uk-navbar-toggle uk-navbar-toggle-alt uk-icon-medium" data-uk-offcanvas></a>
        </div>
        <div class="uk-navbar-brand uk-navbar-center uk-visible-small"><i class="uk-icon-small uk-text-primary uk-margin-small-right uk-icon-play-circle"></i> {{$setting->textlogo}}</div>
    </div>
</nav>
<nav class="uk-navbar uk-navbar-secondary  uk-hidden-small">
    <div class="uk-container-center uk-container">
        <ul class="uk-navbar-nav">
            <li class="uk-active"><a href="{{route('homepage')}}">Home</a></li>
            <li><a href="{{route('movies')}}">Movies</a></li>
            <li><a href="{{route('tvshows')}}">TV Shows</a></li>
            <li class="uk-parent" data-uk-dropdown>
                <a href="">Genre <i class="uk-icon-angle-down uk-margin-small-left"></i></a>
                <div class="uk-dropdown uk-dropdown-navbar">
                    <ul class="uk-nav uk-nav-navbar">
                        @foreach($categories as $category)
                        <li><a href="{{route('category', $category->name)}}">{{ucfirst($category->name)}}</a></li>
                        @endforeach
                    </ul>
                </div>
            </li>
        </ul>
        <div class="uk-navbar-flip">
            <form class="uk-search uk-margin-small-top uk-margin-left uk-hidden-small" method="get" action="/search">
                <input class="uk-search-field" type="search" placeholder="Search..." autocomplete="off" name="q">
                <div class="uk-dropdown uk-dropdown-flip uk-dropdown-search" aria-expanded="false"></div>
            </form>
        </div>
    </div>
</nav>

<!--     ./ Header Section   -->


@yield('content')

<!--     start Footer Section   -->

<footer id="tm-footer" class="uk-block uk-block-secondary uk-block-small ">
    <div class="uk-container-center uk-container">
        <div class="uk-grid">
            <div class="uk-width-medium-3-10"><div class="copyright-text">{{$setting->copyright}}</div></div>
            <div class="uk-width-medium-5-10">
                <ul class="uk-subnav ">
                    <li><a href="{{route('homepage')}}">Home</a></li>
                    <li><a href="{{route('faq')}}">FAQ's</a></li>
                    <li><a href="{{route('terms')}}">Terms & Conditions</a></li>
                    <li><a href="{{route('privacy')}}">Privacy Policy</a></li>
                    <li><a href="{{route('contact')}}">Contact Us</a></li>
                </ul></div>
            <div class="uk-width-medium-2-10">
                <div class=" uk-float-right"><ul class="uk-subnav">
                        <li><a target="_blank" href="{{$setting->facebook}}" class="uk-icon-hover uk-icon-medium uk-icon-facebook-square"></a></li>
                        <li><a target="_blank" href="{{$setting->twitter}}" class="uk-icon-hover uk-icon-medium uk-icon-twitter"></a></li>
                        <li><a target="_blank" href="{{$setting->instagram}}" class="uk-icon-hover uk-icon-medium uk-icon-instagram"></a></li>
                        <li><a target="_blank" href="{{$setting->pinterest}}" class="uk-icon-hover uk-icon-medium uk-icon-pinterest"></a></li>
                    </ul></div></div>
        </div>
    </div>
</footer>

<!--     start Offcanvas Menu   -->

<div id="offcanvas" class="uk-offcanvas">
    <div class="uk-offcanvas-bar">
        <div class="uk-panel">
            <form class="uk-search"  method="get" action="/search">
                <input class="uk-search-field" type="search" placeholder="Search..." name="q">
            </form>
            <div class="uk-button-group">
                @if(Auth::guest())
                    <a class="uk-button uk-button-link uk-button-large uk-text-muted" href="{{url('/register')}}">Sign up</a>
                    <a class="uk-button uk-button-success uk-button-large uk-margin-left" href="{{url('/login')}}"><i class="uk-icon-lock uk-margin-small-right"></i> Log in</a>
                @else
                    <a class="uk-button uk-button-link uk-button-large" href="{{route('logout')}}">Logout</a>
                    <a class="uk-button uk-button-success uk-button-large uk-margin-left" href="{{route('home')}}"><i class="uk-icon-lock uk-margin-small-right"></i> Dashboard</a>
                @endif

            </div>
        </div>
        <ul class="uk-nav uk-nav-offcanvas uk-nav-parent-icon" data-uk-nav>
            <li class="uk-active">
                <a href="{{route('homepage')}}">Home</a>
            </li>
            <li>
                <a href="{{route('movies')}}">Movies</a>
            </li>
            <li>
                <a href="">TV Shows</a>
            </li>
            <li class="uk-parent">
                <a href="#">Genre</a>
                <ul class="uk-nav-sub">
                    @foreach($categories as $category)
                    <li><a href="{{route('category', $category->name)}}">{{ucfirst($category->name)}}</a></li>
                    @endforeach
                </ul>
            </li>
            <li class="uk-nav-divider"></li>
            <li class="uk-nav-header">Pages</li>
            <li><a href="{{route('faq')}}"> FAQ's</a></li>
            <li><a href="{{route('terms')}}"> Terms & Conditions</a></li>
            <li><a href="{{route('privacy')}}"> Privacy Policy</a></li>
            <li><a href="{{route('contact')}}"> Contact Us</a></li>
        </ul>
        <div class="uk-panel uk-text-center">
            <ul class="uk-subnav">
                <li><a target="_blank" href="{{$setting->facebook}}" class="uk-icon-hover uk-icon-medium uk-icon-facebook-square"></a></li>
                <li><a target="_blank" href="{{$setting->twitter}}" class="uk-icon-hover uk-icon-medium uk-icon-twitter"></a></li>
                <li><a target="_blank" href="{{$setting->instagram}}" class="uk-icon-hover uk-icon-medium uk-icon-instagram"></a></li>
                <li><a target="_blank" href="{{$setting->pinterest}}" class="uk-icon-hover uk-icon-medium uk-icon-pinterest"></a></li>
            </ul>
        </div>
    </div>
</div>

<!--     ./ Offcanvas Menu   -->

<!--     Include JS   -->

        <script src="{{asset('js/all.js')}}"></script>

</body>
</html>