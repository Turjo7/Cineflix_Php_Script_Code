@extends('layouts.default')

@section('content')

    <!--     start Main Content Section   -->

    <div class="uk-container uk-container-center uk-margin-large-top uk-margin-large-bottom">

        <div class="uk-grid">

            <div id="tm-right-section" class="uk-width-large-1-1 uk-width-medium-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">

                <h2 class="inline">Category: {{ ucfirst($cname) }}</h2>

                <div class="uk-grid-width-small-1-3 uk-grid-width-medium-1-4 uk-grid-width-large-1-6" data-uk-grid="{gutter: 20}">

                    @foreach($movies as $movie)

                        <div>
                            <div class="uk-overlay uk-overlay-hover">
                                <img src="https://image.tmdb.org/t/p/w500{{$movie->poster}}" alt="Image" >
                                <div class="uk-overlay-panel uk-overlay-fade uk-overlay-background  uk-overlay-icon"></div>
                                <a class="uk-position-cover" href="{{route('movie_detail', $movie->slug)}}"></a>
                            </div>
                            <div class="uk-panel uk-container-center">

                                <h5 class="uk-panel-title">{{str_limit($movie->title, 20)}}</h5>

                            </div>
                        </div>

                    @endforeach

                </div>

            </div>
        </div>
    </div>

    <!--     ./ Main Content Section   -->

@endsection
