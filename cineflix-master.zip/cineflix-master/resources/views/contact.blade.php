@extends('layouts.default')

@section('content')

    <!--     start Main Content Section   -->

    <div class="uk-container uk-container-center uk-margin-large-top uk-margin-large-bottom">

        <div class="uk-grid">

            <div id="tm-right-section" class="uk-width-large-1-1 uk-width-medium-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">

                <h2 class="inline">Contact Us</h2>

                <div>
                    {!! $page->contact !!}
                </div>

            </div>
        </div>
    </div>

    <!--     ./ Main Content Section   -->

@endsection
