@extends('layouts.season')

@section('content')

    <!-- start Main Content (Media Page Section) -->

    @if($setting->watch == 0)

    <div id="tm-media-section" class="uk-block uk-block-small">

        <div class="custom-bg">

            @if($setting->display_ads == 1)
                <div class="uk-grid">
                    <div class="uk-width-1-1">
                        <div class="uk-width-medium-1-2 uk-container-center">
                            {!! $ad->large !!}
                        </div>
                    </div>
                </div>
            @endif

            <div class="uk-container uk-container-center uk-width-8-10">
                <div class="media-container  uk-container-center">
                    <a class="uk-button uk-button-large uk-button-link uk-text-muted" href="{{route('tvshow_detail', $tvshow->slug)}}"><i class=" uk-icon-arrow-left uk-margin-small-right"></i> Back</a>
                </div>

                <div class="uk-grid">
                    <div class="uk-width-medium-3-10">
                        <div  class="media-cover">
                            <img src="https://image.tmdb.org/t/p/w500{{$tvshow->poster}}" alt="Image" class="uk-scrollspy-inview uk-animation-fade">
                        </div>
                    </div>
                    <div class="uk-width-medium-7-10">

                        <h2>Watch {{ucfirst($tvshow->name)}} Season {{$seasonNumber}}</h2>

                        <table class="uk-table uk-table-striped">
                            <thead>
                            <tr>
                                <th>Episode Nr</th>
                                <th>Title</th>
                                <th>Air Date</th>
                                <th>Vote Average</th>
                            </tr>
                            </thead>
                            <tbody>
                               @foreach($episodes as $episode)

                                   <tr>
                                       <td>{{$episode->episode_number}}</td>
                                       <td>{{$episode->title}}</td>
                                       <td>{{$episode->air_date}}</td>
                                       <td>{{$episode->vote_average}}</td>
                                       <td>
                                           <button class="uk-button uk-button-small uk-button-danger" type="button" data-uk-modal="{target:'#{{$episode->episode_number}}'}"><i class="uk-icon-eye"></i> Watch</button>
                                           <div id="{{$episode->episode_number}}" class="uk-modal">
                                               <div class="uk-modal-dialog">
                                                   <a class="uk-modal-close uk-close"></a>

                                                   <h3>{{ucfirst($tvshow->titile)}} Episode {{$episode->episode_number}}</h3>

                                                   <div class="space"></div>

                                                   <article class="uk-comment">
                                                       <header class="uk-comment-header">
                                                           <img class="uk-comment-avatar" width="200" src="https://image.tmdb.org/t/p/w500{{$episode->poster}}" alt="The_Flash_Season_{{$seasonNumber}}_Episode_{{$episode->episode_number}}">
                                                           <h4 class="uk-comment-title">{{$episode->overview}}</h4>
                                                       </header>
                                                   </article>

                                                   <iframe src="{{$episode->video}}?autoplay=0&amp;controls=0&amp;showinfo=0&amp;rel=0&amp;loop=1&amp;modestbranding=1&amp;wmode=transparent" width="560" height="315" frameborder="0" allowfullscreen=""></iframe>
                                               </div>
                                           </div>
                                       </td>
                                   </tr>

                               @endforeach
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>

    </div>

    @else

        @if(Auth::check())

            <div id="tm-media-section" class="uk-block uk-block-small">

                <div class="custom-bg">

                    @if($setting->display_ads == 1)
                        <div class="uk-grid">
                            <div class="uk-width-1-1">
                                <div class="uk-width-medium-1-2 uk-container-center">
                                    {!! $ad->large !!}
                                </div>
                            </div>
                        </div>
                    @endif

                    <div class="uk-container uk-container-center uk-width-8-10">
                        <div class="media-container  uk-container-center">
                            <a class="uk-button uk-button-large uk-button-link uk-text-muted" href="{{route('tvshow_detail', $tvshow->slug)}}"><i class=" uk-icon-arrow-left uk-margin-small-right"></i> Back</a>
                        </div>

                        <div class="uk-grid">
                            <div class="uk-width-medium-3-10">
                                <div  class="media-cover">
                                    <img src="https://image.tmdb.org/t/p/w500{{$tvshow->poster}}" alt="Image" class="uk-scrollspy-inview uk-animation-fade">
                                </div>
                            </div>
                            <div class="uk-width-medium-7-10">

                                <h2>Watch {{ucfirst($tvshow->name)}} Season {{$seasonNumber}}</h2>

                                <table class="uk-table uk-table-striped">
                                    <thead>
                                    <tr>
                                        <th>Episode Nr</th>
                                        <th>Title</th>
                                        <th>Air Date</th>
                                        <th>Vote Average</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($episodes as $episode)

                                        <tr>
                                            <td>{{$episode->episode_number}}</td>
                                            <td>{{$episode->title}}</td>
                                            <td>{{$episode->air_date}}</td>
                                            <td>{{$episode->vote_average}}</td>
                                            <td>
                                                <button class="uk-button uk-button-small uk-button-danger" type="button" data-uk-modal="{target:'#{{$episode->episode_number}}'}"><i class="uk-icon-eye"></i> Watch</button>
                                                <div id="{{$episode->episode_number}}" class="uk-modal">
                                                    <div class="uk-modal-dialog">
                                                        <a class="uk-modal-close uk-close"></a>

                                                        <h3>{{ucfirst($tvshow->titile)}} Episode {{$episode->episode_number}}</h3>

                                                        <div class="space"></div>

                                                        <article class="uk-comment">
                                                            <header class="uk-comment-header">
                                                                <img class="uk-comment-avatar" width="200" src="https://image.tmdb.org/t/p/w500{{$episode->poster}}" alt="The_Flash_Season_{{$seasonNumber}}_Episode_{{$episode->episode_number}}">
                                                                <h4 class="uk-comment-title">{{$episode->overview}}</h4>
                                                            </header>
                                                        </article>

                                                        <iframe src="{{$episode->video}}?autoplay=0&amp;controls=0&amp;showinfo=0&amp;rel=0&amp;loop=1&amp;modestbranding=1&amp;wmode=transparent" width="560" height="315" frameborder="0" allowfullscreen=""></iframe>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>

                                    @endforeach
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>

            </div>

        @else

            <div class="uk-width-medium-1-2 uk-container-center uk-align-center">

                <div class="space"></div>
                <h2>You have to be registered to watch tv shows online</h2>

            </div>

        @endif

    @endif

    </div>

    <!-- ./ Main Content (Media Page Section) -->

@endsection