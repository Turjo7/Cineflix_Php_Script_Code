@if(count($errors) > 0)

    <div class="uk-alert uk-alert-warning">

        <ul>
            @foreach($errors->all() as $error)

                <li>{{$error}}</li>

            @endforeach
        </ul>

    </div>

@endif