<script src="https://cloud.tinymce.com/5/tinymce.min.js?apiKey=0cql9p35sn92vzkendop2mk33qrij8xzzfynb0rk7jwejtig"></script>
<script>
    tinymce.init({
        selector: '#mytextarea'
    });
    tinymce.init({
        selector: '#mytextarea2'
    });
    tinymce.init({
        selector: '#mytextarea3'
    });
    tinymce.init({
        selector: '#mytextarea4'
    });
</script>