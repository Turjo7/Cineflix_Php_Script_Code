@extends('layouts.default')

@section('content')

    <!--     start Main Content Section   -->

    <div class="uk-container uk-container-center uk-margin-large-top uk-margin-large-bottom">

        @if($setting->display_ads == 1)
            <div class="uk-grid">
                <div class="uk-width-1-1">
                    <div class="uk-width-medium-1-2 uk-container-center">
                        {!! $ad->large !!}
                    </div>
                </div>
            </div>
        @endif

        <div class="uk-grid">

            <div id="tm-right-section" class="uk-width-large-1-1 uk-width-medium-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">

                <h2 class="inline">Newly added</h2>
                <a href="{{route('movies')}}" class="inline viewall uk-float-right"><i class="uk-icon-circle-o-notch"></i> View All</a>
                <div class="uk-grid-width-small-1-3 uk-grid-width-medium-1-4 uk-grid-width-large-1-6" data-uk-grid="{gutter: 20}">

                    @foreach($allmovies as $allmovie)

                    <div>
                        <div class="uk-overlay uk-overlay-hover">
                            @if($allmovie->imported == 1)
                            <img src="https://image.tmdb.org/t/p/w500{{$allmovie->poster}}" alt="Image" >
                            @else
                                <img src="img/{{$allmovie->poster}}" alt="Image" >
                            @endif
                            <div class="uk-overlay-panel uk-overlay-fade uk-overlay-background  uk-overlay-icon"></div>
                            <a class="uk-position-cover" href="{{route('movie_detail', $allmovie->slug)}}"></a>
                        </div>
                        <div class="uk-panel uk-container-center">

                            <h5 class="uk-panel-title">{{str_limit($allmovie->title, 20)}}</h5>

                        </div>
                    </div>

                    @endforeach

                </div>

                <h2 class="inline">Tv Shows</h2>
                <a href="{{route('tvshows')}}" class="inline viewall uk-float-right"><i class="uk-icon-circle-o-notch"></i> View All</a>
                <div class="uk-grid-width-small-1-3 uk-grid-width-medium-1-4 uk-grid-width-large-1-6" data-uk-grid="{gutter: 20}">

                    @foreach($tvshows as $tvshow)

                        <div>
                            <div class="uk-overlay uk-overlay-hover">
                                    <img src="https://image.tmdb.org/t/p/w500{{$tvshow->poster}}" alt="Image" >
                                <div class="uk-overlay-panel uk-overlay-fade uk-overlay-background  uk-overlay-icon"></div>
                                <a class="uk-position-cover" href="{{route('tvshow_detail', $tvshow->slug)}}"></a>
                            </div>
                            <div class="uk-panel uk-container-center">

                                <h5 class="uk-panel-title">{{str_limit($tvshow->name, 20)}}</h5>

                            </div>
                        </div>

                    @endforeach

                </div>

                <h2 class="inline">Comedy</h2>
                <a href="{{route('category', 'comedy')}}" class="inline viewall uk-float-right"><i class="uk-icon-circle-o-notch"></i> View All</a>
                <div class="uk-grid-width-small-1-3 uk-grid-width-medium-1-4 uk-grid-width-large-1-6" data-uk-grid="{gutter: 20}">

                    @foreach($cmovies as $cmovie)

                        <div>
                            <div class="uk-overlay uk-overlay-hover">
                                @if($cmovie->imported == 1)
                                    <img src="https://image.tmdb.org/t/p/w500{{$cmovie->poster}}" alt="Image" >
                                @else
                                    <img src="img/{{$cmovie->poster}}" alt="Image" >
                                @endif
                                <div class="uk-overlay-panel uk-overlay-fade uk-overlay-background  uk-overlay-icon"></div>
                                <a class="uk-position-cover" href="{{route('movie_detail', $cmovie->slug)}}"></a>
                            </div>
                            <div class="uk-panel uk-container-center">

                                <h5 class="uk-panel-title">{{str_limit($cmovie->title, 15)}}</h5>

                            </div>
                        </div>

                    @endforeach

                </div>

                <h2 class="inline">Superhero</h2>
                <a href="{{route('category', 'superhero')}}" class="inline viewall uk-float-right"><i class="uk-icon-circle-o-notch"></i> View All</a>
                <div class="uk-grid-width-small-1-3 uk-grid-width-medium-1-4 uk-grid-width-large-1-6" data-uk-grid="{gutter: 20}">

                    @foreach($smovies as $smovie)

                        <div>
                            <div class="uk-overlay uk-overlay-hover">
                                @if($smovie->imported == 1)
                                    <img src="https://image.tmdb.org/t/p/w500{{$smovie->poster}}" alt="Image" >
                                @else
                                    <img src="img/{{$smovie->poster}}" alt="Image" >
                                @endif
                                <div class="uk-overlay-panel uk-overlay-fade uk-overlay-background  uk-overlay-icon"></div>
                                <a class="uk-position-cover" href="{{route('movie_detail', $smovie->slug)}}"></a>
                            </div>
                            <div class="uk-panel uk-container-center">

                                <h5 class="uk-panel-title">{{str_limit($smovie->title, 15)}}</h5>

                            </div>
                        </div>

                    @endforeach

                </div>

                <h2 class="inline">Horror</h2>
                <a href="{{route('category', 'horror')}}" class="inline viewall uk-float-right"><i class="uk-icon-circle-o-notch"></i> View All</a>
                <div class="uk-grid-width-small-1-3 uk-grid-width-medium-1-4 uk-grid-width-large-1-6" data-uk-grid="{gutter: 20}">

                    @foreach($hmovies as $hmovie)

                        <div>
                            <div class="uk-overlay uk-overlay-hover">
                                @if($hmovie->imported == 1)
                                    <img src="https://image.tmdb.org/t/p/w500{{$hmovie->poster}}" alt="Image" >
                                @else
                                    <img src="img/{{$hmovie->poster}}" alt="Image" >
                                @endif
                                <div class="uk-overlay-panel uk-overlay-fade uk-overlay-background  uk-overlay-icon"></div>
                                <a class="uk-position-cover" href="{{route('movie_detail', $hmovie->slug)}}"></a>
                            </div>
                            <div class="uk-panel uk-container-center">

                                <h5 class="uk-panel-title">{{str_limit($hmovie->title, 15)}}</h5>

                            </div>
                        </div>

                    @endforeach

                </div>

                <h2 class="inline">Adventure</h2>
                <a href="{{route('category', 'adventure')}}" class="inline viewall uk-float-right"><i class="uk-icon-circle-o-notch"></i> View All</a>
                <div class="uk-grid-width-small-1-3 uk-grid-width-medium-1-4 uk-grid-width-large-1-6" data-uk-grid="{gutter: 20}">

                    @foreach($amovies as $amovie)

                        <div>
                            <div class="uk-overlay uk-overlay-hover">
                                @if($amovie->imported == 1)
                                    <img src="https://image.tmdb.org/t/p/w500{{$amovie->poster}}" alt="Image" >
                                @else
                                    <img src="img/{{$amovie->poster}}" alt="Image" >
                                @endif
                                <div class="uk-overlay-panel uk-overlay-fade uk-overlay-background  uk-overlay-icon"></div>
                                <a class="uk-position-cover" href="{{route('movie_detail', $amovie->slug)}}"></a>
                            </div>
                            <div class="uk-panel uk-container-center">

                                <h5 class="uk-panel-title">{{str_limit($amovie->title, 15)}}</h5>

                            </div>
                        </div>

                    @endforeach

                </div>

                <h2 class="inline">Animation</h2>
                <a href="{{route('category', 'animation')}}" class="inline viewall uk-float-right"><i class="uk-icon-circle-o-notch"></i> View All</a>
                <div class="uk-grid-width-small-1-3 uk-grid-width-medium-1-4 uk-grid-width-large-1-6" data-uk-grid="{gutter: 20}">

                    @foreach($anmovies as $anmovie)

                        <div>
                            <div class="uk-overlay uk-overlay-hover">
                                @if($anmovie->imported == 1)
                                    <img src="https://image.tmdb.org/t/p/w500{{$anmovie->poster}}" alt="Image" >
                                @else
                                    <img src="img/{{$anmovie->poster}}" alt="Image" >
                                @endif
                                <div class="uk-overlay-panel uk-overlay-fade uk-overlay-background movie-overlay  uk-overlay-icon"></div>
                                <a class="uk-position-cover" href="{{route('movie_detail', $anmovie->slug)}}"></a>
                            </div>
                            <div class="uk-panel uk-container-center">

                                <h5 class="uk-panel-title">{{str_limit($anmovie->title, 15)}}</h5>

                            </div>
                        </div>

                    @endforeach

                </div>

            </div>
        </div>

            @if($setting->display_ads == 1)
                <div class="uk-grid">
                    <div class="uk-width-1-1">
                        <div class="uk-width-medium-1-2 uk-container-center">
                            {!! $ad->large !!}
                        </div>
                    </div>
                </div>
            @endif

    </div>

    <!--     ./ Main Content Section   -->

@endsection
