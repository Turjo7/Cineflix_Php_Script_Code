@extends('layouts.admin')

@section('content')

    @include('includes.tinyeditor')

    <div id="tm-right-section" class="uk-width-large-8-10 uk-width-medium-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">

        @if(Session::has('status'))

            <div class="uk-grid">
                <div class="uk-width-1-1">
                    <div class="uk-alert uk-alert-success" data-uk-alert>
                        <a href="" class="uk-alert-close uk-close"></a>
                        <p>{{session('status')}}</p>
                    </div>
                </div>
            </div>

        @endif

        <div class="space"></div>

        <div class="space"></div>
        <div class="space"></div>

        <div class="uk-width-medium-1-1 uk-row-first">

            <div class="uk-grid">
                <div class="uk-width-medium-3-10">

                    <ul class="uk-tab uk-tab-left" data-uk-tab="{connect:'#tab-left-content'}">
                        <li class="uk-active" aria-expanded="true"><a href="#">728x90</a></li>
                        <li aria-expanded="false" class=""><a href="#">468x60</a></li>
                    </ul>

                </div>
                <div class="uk-width-medium-7-10">

                    <ul id="tab-left-content" class="uk-switcher">
                        <li class="uk-active" aria-hidden="false">

                            <form class="uk-form" method="post" action="{{action('AdminAdsController@update', $ad->id)}}" enctype="multipart/form-data">
                                @csrf
                                @method('PATCH')
                                <h4>AD format 728x90</h4>
                                <p>Configure 728x90 format</p>

                                <div class="space"></div>

                                <div class="uk-form-row">

                                    <label class="uk-form-label" for="copyright">728x90</label>
                                    <div class="uk-width-1-1">
                                        <textarea class="uk-width-1-1" rows="5" placeholder="..." name="large">{{$ad->large}}</textarea>
                                    </div>

                                </div>


                                <div class="uk-form-row">
                                    <button class="uk-button uk-button-primary" type="submit">Save</button>
                                </div>

                            </form>
                        </li>
                        <li aria-hidden="true" class="">

                            <form class="uk-form" method="post" action="{{action('AdminAdsController@update', $ad->id)}}" enctype="multipart/form-data">
                                @csrf
                                @method('PATCH')
                                <h4>AD format 468x60</h4>
                                <p>Configure 468x60 format</p>

                                <div class="space"></div>

                                <div class="uk-form-row">

                                    <label class="uk-form-label" for="copyright">468x60</label>
                                    <div class="uk-width-1-1">
                                        <textarea class="uk-width-1-1" rows="5" placeholder="..." name="small">{{$ad->small}}</textarea>
                                    </div>

                                </div>


                                <div class="uk-form-row">
                                    <button class="uk-button uk-button-primary" type="submit">Save</button>
                                </div>

                            </form>

                        </li>
                    </ul>

                </div>
            </div>

        </div>

    </div>

    </div>
    </div>
    </div>
    <!--     ./ Main Section   -->

@endsection