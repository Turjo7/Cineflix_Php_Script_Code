@extends('layouts.admin')

@section('content')


    <div id="tm-right-section" class="uk-width-large-8-10 uk-width-medium-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">

        <div class="uk-grid">

            <div class="uk-width-1-1">
                @include('includes.errors')

                @if(Session::has('status'))

                    <div class="uk-alert uk-alert-success" data-uk-alert>
                        <a href="" class="uk-alert-close uk-close"></a>
                        <p>{{session('status')}}</p>
                    </div>
                @endif

            </div>

        </div>

        <div class="uk-grid">

            <div class="uk-width-3-10">
                Create a category
                <form class="uk-form" method="post" action="{{action('AdminCategoriesController@store')}}">
                    @csrf
                    <div class="uk-form-row">
                        <input type="text" placeholder="Name" class="uk-width-1-1" name="name">
                    </div>

                    <div class="uk-form-row">
                        <button class="uk-button uk-button-primary" type="submit">Add Category</button>
                    </div>

                </form>
            </div>

            <div class="uk-width-7-10">

                <table class="uk-table uk-table-hover uk-table-striped uk-table-condensed">
                    <p>All Categories</p>
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Created</th>
                        <th>Updated</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($categories as $category)
                        <tr>
                            <td>{{$category->id}}</td>
                            <td>{{$category->name}}</td>
                            <td>{{$category->created_at->diffForHumans()}}</td>
                            <td>{{$category->updated_at->diffForHumans()}}</td>
                            <td><a href="{{route('admin.categories.edit', $category->id)}}"><i class="uk-icon-edit"></a></td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>

            </div>

        </div>

        </div>

    </div>

    </div>
    </div>
    </div>
    <!--     ./ Main Section   -->

@endsection