@extends('layouts.admin')

@section('content')

    @include('includes.tinyeditor')

    <div id="tm-right-section" class="uk-width-large-8-10 uk-width-medium-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">

        @if(Session::has('status'))

            <div class="uk-grid">
                <div class="uk-width-1-1">
                    <div class="uk-alert uk-alert-success" data-uk-alert>
                        <a href="" class="uk-alert-close uk-close"></a>
                        <p>{{session('status')}}</p>
                    </div>
                </div>
            </div>

        @endif

        <div class="space"></div>

        <div class="space"></div>
        <div class="space"></div>

        <div class="uk-width-medium-1-1 uk-row-first">

            <div class="uk-grid">
                <div class="uk-width-medium-3-10">

                    <ul class="uk-tab uk-tab-left" data-uk-tab="{connect:'#tab-left-content'}">
                        <li class="uk-active" aria-expanded="true"><a href="#">FAQ</a></li>
                        <li aria-expanded="false" class=""><a href="#">Terms & Conditions</a></li>
                        <li aria-expanded="false" class=""><a href="#">Privacy Policy</a></li>
                        <li aria-expanded="false" class=""><a href="#">Contact Us</a></li>
                    </ul>

                </div>
                <div class="uk-width-medium-7-10">

                    <ul id="tab-left-content" class="uk-switcher">
                        <li class="uk-active" aria-hidden="false">

                            <form class="uk-form" method="post" action="{{action('AdminPagesController@update', $page->id)}}" enctype="multipart/form-data">
                                @csrf
                                @method('PATCH')
                                <h4>FAQ</h4>
                                <p>Configure FAQ page</p>

                                <div class="space"></div>

                                <div class="uk-form-row">

                                    <label class="uk-form-label" for="copyright">FAQ</label>
                                    <div class="uk-width-1-1">
                                        <textarea id="mytextarea" class="uk-width-1-1" rows="5" placeholder="..." name="faq">{{$page->faq}}</textarea>
                                    </div>

                                </div>


                                <div class="uk-form-row">
                                    <button class="uk-button uk-button-primary" type="submit">Save</button>
                                </div>

                            </form>
                        </li>
                        <li aria-hidden="true" class="">

                            <form class="uk-form" method="post" action="{{action('AdminPagesController@update', $page->id)}}" enctype="multipart/form-data">
                                @csrf
                                @method('PATCH')
                                <h4>Terms & Conditions</h4>
                                <p>Configure Terms & Conditions page</p>

                                <div class="space"></div>

                                <div class="uk-form-row">

                                    <label class="uk-form-label" for="copyright">Terms and Conditions</label>
                                    <div class="uk-width-1-1">
                                        <textarea id="mytextarea2" class="uk-width-1-1" rows="5" placeholder="..." name="terms">{{$page->terms}}</textarea>
                                    </div>

                                </div>


                                <div class="uk-form-row">
                                    <button class="uk-button uk-button-primary" type="submit">Save</button>
                                </div>

                            </form>

                        </li>
                        <li aria-hidden="true" class="">

                            <form class="uk-form" method="post" action="{{action('AdminPagesController@update', $page->id)}}" enctype="multipart/form-data">
                                @csrf
                                @method('PATCH')
                                <h4>Privacy Policy</h4>
                                <p>Configure Privacy Policy page</p>

                                <div class="space"></div>

                                <div class="uk-form-row">

                                    <label class="uk-form-label" for="copyright">Privacy Policy</label>
                                    <div class="uk-width-1-1">
                                        <textarea id="mytextarea3" class="uk-width-1-1" rows="5" placeholder="..." name="privacy">{{$page->privacy}}</textarea>
                                    </div>

                                </div>


                                <div class="uk-form-row">
                                    <button class="uk-button uk-button-primary" type="submit">Save</button>
                                </div>

                            </form>

                        </li>
                        <li aria-hidden="true">

                            <form class="uk-form" method="post" action="{{action('AdminPagesController@update', $page->id)}}" enctype="multipart/form-data">
                                @csrf
                                @method('PATCH')
                                <h4>Contact Us</h4>
                                <p>Configure Contact page</p>

                                <div class="space"></div>

                                <div class="uk-form-row">

                                    <label class="uk-form-label" for="copyright">Contact Us</label>
                                    <div class="uk-width-1-1">
                                        <textarea id="mytextarea4" class="uk-width-1-1" rows="5" placeholder="..." name="contact">{{$page->contact}}</textarea>
                                    </div>

                                </div>


                                <div class="uk-form-row">
                                    <button class="uk-button uk-button-primary" type="submit">Save</button>
                                </div>

                            </form>

                        </li>
                    </ul>

                </div>
            </div>

        </div>

    </div>

    </div>
    </div>
    </div>
    <!--     ./ Main Section   -->

@endsection