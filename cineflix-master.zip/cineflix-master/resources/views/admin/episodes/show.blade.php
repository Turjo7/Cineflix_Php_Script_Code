@extends('layouts.admin')

@section('content')

    <div id="tm-right-section" class="uk-width-large-8-10 uk-width-medium-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">

        <div class="uk-grid">

            <div class="uk-width-7-10 uk-clearfix">

                <form class="uk-form" method="post" action="{{action('EpisodeController@store')}}" enctype="multipart/form-data">
                    @csrf
                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Title:</label>
                        <input type="text" placeholder="Movie Title" class="uk-width-1-1" name="title" value="{{$episode['name']}}">

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Air Date:</label>
                        <input type="date" placeholder="Release Date" class="uk-width-1-1" name="air_date" value="{{$episode['air_date']}}">

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Overview:</label>
                        <textarea class="uk-width-1-1" rows="5" placeholder="Add Overview" name="overview">{{$episode['overview']}}</textarea>

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Vote Average:</label>
                        <input type="text" placeholder="Vote Average" class="uk-width-1-1" name="vote_average" value="{{$episode['vote_average']}}">

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Video:</label>
                        <input type="text" placeholder="https://www.youtube.com/embed/ZsBO4b3tyZg" class="uk-width-1-1" name="video" value="">

                    </div>

                    <input type="hidden" name="poster" value="{{$episode['still_path']}}">
                    <input type="hidden" name="tvshow_id_local" value="{{$tvshow_id_local}}">
                    <input type="hidden" name="episode_number" value="{{$episode['episode_number']}}">
                    <input type="hidden" name="season_id" value="{{$episode['season_number']}}">

                    <div class="space"></div>

                    <div class="uk-form-row">
                        <button class="uk-button uk-button-primary uk-float-left" type="submit">Save</button>
                    </div>


                </form>

            </div>

            <div class="uk-width-3-10">

                <img src="https://image.tmdb.org/t/p/w500{{$episode['still_path']}}">
                <div class="space"></div>
                Episode: {{$episode['episode_number']}}
                @include('includes.errors')

            </div>

        </div>

    </div>

    </div>
    </div>
    </div>
    <!--     ./ Main Section   -->


@endsection