@extends('layouts.admin')

@section('content')

    <div id="tm-right-section" class="uk-width-large-8-10 uk-width-medium-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">

        <div class="uk-grid">
            <div class="uk-width-1-4">

                <div class="uk-panel anymovie-panel">
                    <div class="uk-panel-badge uk-badge">Total Movies</div>
                    <h3 class="uk-panel-title anymovie-panel-title uk-text-center"><i class="uk-icon-tv"></i> {{$movies}}</h3>
                </div>

            </div>
            <div class="uk-width-1-4">

                <div class="uk-panel anymovie-panel">
                    <div class="uk-panel-badge uk-badge">Total Series</div>
                    <h3 class="uk-panel-title anymovie-panel-title uk-text-center"><i class="uk-icon-video-camera"></i> {{$tvshows}}</h3>
                </div>

            </div>
            <div class="uk-width-1-4">

                <div class="uk-panel anymovie-panel">
                    <div class="uk-panel-badge uk-badge">Total Reviews</div>
                    <h3 class="uk-panel-title anymovie-panel-title uk-text-center"><i class="uk-icon-commenting"></i> {{$allreviews}}</h3>
                </div>

            </div>
            <div class="uk-width-1-4">

                <div class="uk-panel anymovie-panel">
                    <div class="uk-panel-badge uk-badge">Total Users</div>
                    <h3 class="uk-panel-title anymovie-panel-title uk-text-center"><i class="uk-icon-users"></i> {{$users}}</h3>
                </div>

            </div>
        </div>

        <div class="uk-grid" data-uk-grid-margin="">
            <div class="uk-width-medium-1-3 uk-row-first">
                <div class="uk-panel admin-panel uk-panel-box">
                    <h3 class="uk-panel-title"><i class="uk-icon-commenting-o"></i> Pending Reviews</h3>
                    There are <span class="uk-text-bold uk-text-success">{{$reviews}}</span> review(s) in moderation.
                </div>
            </div>
            <div class="uk-width-medium-1-3">
                <div class="uk-panel admin-panel uk-panel-box">
                    <h3 class="uk-panel-title"><i class="uk-icon-search"></i> Today Searches</h3>
                    There are <span class="uk-text-bold uk-text-success">{{$todaySearch}}</span> new searches today.
                </div>
            </div>
            <div class="uk-width-medium-1-3">
                <div class="uk-panel admin-panel uk-panel-box">
                    <h3 class="uk-panel-title"><i class="uk-icon-user-plus"></i> Today Users</h3>
                    There are <span class="uk-text-bold uk-text-success">{{$todayUsers}}</span> new registered users.
                </div>
            </div>
        </div>

        <div class="uk-grid">

            <div class="uk-width-medium-1-2">
                <h4>Latest 10 Search queries</h4>
                <table class="uk-table uk-table-hover uk-table-striped uk-table-condensed">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Created</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($searches as $search)
                        <tr>
                            <td>{{$search->id}}</td>
                            <td>{{$search->title}}</td>
                            <td>{{$search->created_at->diffForHumans()}}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>

            <div class="uk-width-medium-1-2">
                <h4>Latest 10 Registered users</h4>
                <table class="uk-table uk-table-hover uk-table-striped uk-table-condensed">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Created</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($newUsers as $newUser)
                        <tr>
                            <td>{{$newUser->id}}</td>
                            <td>{{$newUser->name}}</td>
                            <td>{{$newUser->email}}</td>
                            <td>{{$newUser->created_at->diffForHumans()}}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>

        </div>

    </div>
    </div>
    </div>
    <!--     ./ Main Section   -->

@endsection