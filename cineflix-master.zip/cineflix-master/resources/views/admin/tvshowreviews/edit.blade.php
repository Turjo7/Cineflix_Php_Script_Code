@extends('layouts.admin')

@section('content')

    <div id="tm-right-section" class="uk-width-large-8-10 uk-width-medium-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">

        <div class="uk-grid">

            <div class="uk-width-7-10 uk-clearfix">

                <form class="uk-form" method="post" action="{{action('AdminTvShowReviewController@update', $review->id)}}" enctype="multipart/form-data">
                    @csrf
                    @method('patch')
                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Author: {{$review->author}}</label>

                    </div>


                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Comment:</label>
                        <textarea class="uk-width-1-1" rows="5" placeholder="Review comment" name="body">{{$review->body}}</textarea>

                    </div>
                    <input type="hidden" name="is_active" value="1">
                    <div class="space"></div>
                    <button class="uk-button uk-button-success" type="submit">Approve</button>

                </form>

                <form class="uk-form uk-float-right delete-form" method="post" action="{{action('AdminTvShowReviewController@destroy', $review->id)}}">
                    @csrf
                    @method('delete')
                    <button class="uk-button uk-button-danger" type="submit">Delete</button>
                </form>

            </div>

            <div class="uk-width-3-10">
                <img src="https://image.tmdb.org/t/p/w500{{$review->tvshows->poster}}">
                @include('includes.errors')
            </div>

        </div>

    </div>

    </div>
    </div>
    </div>
    <!--     ./ Main Section   -->

@endsection