@extends('layouts.admin')

@section('content')

    <div id="tm-right-section" class="uk-width-large-8-10 uk-width-medium-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">

        @if(Session::has('status'))

            <div class="uk-grid">
                <div class="uk-width-1-1">
                    <div class="uk-alert uk-alert-success" data-uk-alert>
                        <a href="" class="uk-alert-close uk-close"></a>
                        <p>{{session('status')}}</p>
                    </div>
                </div>
            </div>

        @endif

        <div class="uk-grid">
            <div class="uk-width-1-1">

                <table class="uk-table uk-table-hover uk-table-striped uk-table-condensed">
                    <p>All Reviews</p>
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tv Show</th>
                        <th>Author</th>
                        <th>Body</th>
                        <th>Created</th>
                        <th>Updated</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($reviews as $review)
                        <tr>
                            <td>{{$review->id}}</td>
                            <td><a href="{{route('tvshow_detail', $review->tvshows->slug)}}" target="_blank">{{$review->tvshows->name}}</a></td>
                            <td>{{$review->author}}</td>
                            <td>{{str_limit($review->body, 20)}}</td>
                            <td>{{$review->created_at->diffForHumans()}}</td>
                            <td>{{$review->updated_at->diffForHumans()}}</td>
                            @if($review->is_active == 0)
                                <td><button class="uk-button uk-button-danger" type="button">Pending</button></td>
                            @else
                                <td><button class="uk-button uk-button-success" type="button">Approved</button></td>
                            @endif
                            <td><a href="{{route('admin.tvshowreviews.edit', $review->id)}}"><i class="uk-icon-edit"></i></a></td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>

            </div>
        </div>

        <div class="space"></div>

        <div class="uk-width-medium-1-2 uk-container-center">
            {{$reviews->links('vendor.pagination.default')}}
        </div>

    </div>

    </div>
    </div>
    </div>
    <!--     ./ Main Section   -->

@endsection