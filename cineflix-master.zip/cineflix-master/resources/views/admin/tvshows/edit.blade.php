@extends('layouts.admin')

@section('content')

    <div id="tm-right-section" class="uk-width-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">
        <div class="uk-grid">

            <div class="uk-width-6-10 uk-clearfix">

                @if(Session::has('status'))

                    <div class="uk-grid">
                        <div class="uk-width-1-1">
                            <div class="uk-alert uk-alert-success" data-uk-alert>
                                <a href="" class="uk-alert-close uk-close"></a>
                                <p>{{session('status')}}</p>
                            </div>
                        </div>
                    </div>

                @endif

                <div class="space"></div>

                <form class="uk-form" method="post" action="{{action('AdminTvshowsController@update', $tvshow->id)}}" enctype="multipart/form-data">
                    @csrf
                    @method('patch')
                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Title:</label>
                        <input type="text" placeholder="Tv Show Title" class="uk-width-1-1" name="name" value="{{$tvshow->name}}">

                    </div>

                    <div class="uk-form-row">
                        <label class="uk-form-label" for="form-s-s">Select Category (Hold CTRL for multiple selection)</label>
                        <div class="uk-form-controls">
                            <select class="uk-width-1-1 minh" id="form-s-s" name="categories_id[]" multiple>

                                @foreach($categories as $category)

                                    <option value="{{$category->id}}">{{ucfirst($category->name)}}</option>

                                @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Release Date:</label>
                        <input type="date" placeholder="Release Date" class="uk-width-1-1" name="first_air_date" value="{{$tvshow->first_air_date}}">

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Overview:</label>
                        <textarea class="uk-width-1-1" rows="5" placeholder="Add Overview" name="overview">{{$tvshow->overview}}</textarea>

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Homepage:</label>
                        <input type="text" placeholder="https://homepage.com" class="uk-width-1-1" name="homepage" value="{{$tvshow->homepage}}">

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Vote Average:</label>
                        <input type="text" placeholder="Vote Average" class="uk-width-1-1" name="vote_average" value="{{$tvshow->vote_average}}">

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Trailer:</label>
                        <input type="text" placeholder="https://www.youtube.com/embed/ZsBO4b3tyZg" class="uk-width-1-1" name="trailer" value="{{$tvshow->trailer}}">

                    </div>

                    <div class="space"></div>

                    <div class="uk-form-row">
                        <button class="uk-button uk-button-primary uk-float-left" type="submit">Save</button>
                    </div>


                </form>

                <form class="uk-form uk-float-right delete-form" method="post" action="{{action('AdminTvshowsController@destroy', $tvshow->id)}}">
                    @csrf
                    @method('delete')
                    <button class="uk-button uk-button-danger" type="submit">Delete</button>
                </form>

            </div>

            <div class="uk-width-4-10">

                <img src="https://image.tmdb.org/t/p/w500{{$tvshow->poster}}">
                @include('includes.errors')

                <form class="uk-form" method="post" action="{{action('AdminTvshowsController@addSeason')}}">
                    @csrf
                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="season-number">Season number:</label>
                        <input type="number" placeholder="" min="1" class="uk-width-1-1" name="number">

                    </div>

                    <input type="hidden" name="tvshow_id" value="{{$tvshow->id}}">
                    <div class="space"></div>
                    <button class="uk-button uk-button-success" type="submit">Add Season</button>
                </form>

                <div class="space"></div>

                @if(count($seasons) > 0)

                    <table class="uk-table uk-table-hover uk-table-striped uk-table-condensed">
                        <p>All Seasons</p>
                        <thead>
                        <tr>
                            <th>Nr</th>
                            <th><i class="uk-icon-plus-circle"></i> Episode</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($seasons as $season)
                            <tr>
                                <td>{{$season->number}}</td>
                                <td>

                                    <form class="uk-form uk-float-left" method="post" action="{{action('EpisodeController@import')}}">
                                        @csrf
                                        <input type="number" min="1" placeholder="" class="uk-width-1-3" name="number" required>
                                        <input type="hidden" name="tvshow_id" value="{{$tvshow->tvshow_id}}">
                                        <input type="hidden" name="tvshow_id_local" value="{{$tvshow->id}}">
                                        <input type="hidden" name="season_id" value="{{$season->number}}">
                                        <button class="uk-button uk-button-mini uk-button-primary" type="submit">Add Episode</button>
                                    </form>

                                </td>
                                <td>

                                    <form class="removeButton uk-form" method="post" action="{{action('AdminTvShowSeasonController@deleteSeason')}}">
                                        @csrf
                                        <input type="hidden" name="tvshow_id" value="{{$tvshow->id}}">
                                        <input type="hidden" name="season" value="{{$season->number}}">
                                        <button class="uk-button uk-button-mini uk-button-danger" type="submit">Remove</button>
                                    </form>

                                </td>
                                <td><a href="{{route('season_episodes', ['slug'=>$tvshow->slug, 'number'=>$season->number])}}"><i class="uk-icon-edit"></i></a></td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>

                @endif

            </div>

        </div>

    </div>

    </div>
    </div>
    </div>
    <!--     ./ Main Section   -->


@endsection