@extends('layouts.admin')

@section('content')

    <div id="tm-right-section" class="uk-width-large-8-10 uk-width-medium-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">

        <div class="uk-grid">

            <div class="uk-width-7-10 uk-clearfix">

                <form class="uk-form" method="post" action="{{action('AdminTvshowsController@store')}}" enctype="multipart/form-data">
                    @csrf
                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Title:</label>
                        <input type="text" placeholder="Tv Show Title" class="uk-width-1-1" name="name" value="{{$tvshow['original_name']}}">

                    </div>

                    <div class="uk-form-row">
                        <label class="uk-form-label" for="form-s-s">Select Category (Hold CTRL for multiple selection)</label>
                        <div class="uk-form-controls">
                            <select class="uk-width-1-1 minh" id="form-s-s" name="categories_id[]" multiple>

                                @foreach($categories as $category)

                                    <option value="{{$category->id}}">{{ucfirst($category->name)}}</option>

                                @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Release Date:</label>
                        <input type="date" placeholder="Release Date" class="uk-width-1-1" name="first_air_date" value="{{$tvshow['first_air_date']}}">

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Overview:</label>
                        <textarea class="uk-width-1-1" rows="5" placeholder="Add Overview" name="overview">{{$tvshow['overview']}}</textarea>

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Homepage:</label>
                        <input type="text" placeholder="https://homepage.com" class="uk-width-1-1" name="homepage" value="{{$tvshow['homepage']}}">

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Vote Average:</label>
                        <input type="text" placeholder="Vote Average" class="uk-width-1-1" name="vote_average" value="{{$tvshow['vote_average']}}">

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Trailer:</label>
                        <input type="text" placeholder="https://www.youtube.com/embed/ZsBO4b3tyZg" class="uk-width-1-1" name="trailer" value="">

                    </div>

                    <input type="hidden" name="poster" value="{{$tvshow['poster_path']}}">
                    <input type="hidden" name="tvshow_id" value="{{$tvshow_id}}">
                    <input type="hidden" name="tmdbId" value="{{$tvshow['id']}}">

                    <div class="space"></div>

                    <div class="uk-form-row">
                        <button class="uk-button uk-button-primary uk-float-left" type="submit">Save</button>
                    </div>


                </form>

            </div>

            <div class="uk-width-3-10">

                <img src="https://image.tmdb.org/t/p/w500{{$tvshow['poster_path']}}">
                @include('includes.errors')

            </div>

        </div>

    </div>

    </div>
    </div>
    </div>
    <!--     ./ Main Section   -->


@endsection