@extends('layouts.admin')

@section('content')

    <div id="tm-right-section" class="uk-width-large-8-10 uk-width-medium-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">

        <div class="uk-grid">

            <div class="uk-width-7-10 uk-clearfix">

                @if(Session::has('status'))

                    <div class="uk-grid">
                        <div class="uk-width-1-1">
                            <div class="uk-alert uk-alert-success" data-uk-alert>
                                <a href="" class="uk-alert-close uk-close"></a>
                                <p>{{session('status')}}</p>
                            </div>
                        </div>
                    </div>

                @endif

                <a class="uk-button uk-button-large uk-button-link uk-text-muted" href="{{route('admin.tvshows.edit', $tvshow->id)}}"><i class=" uk-icon-arrow-left uk-margin-small-right"></i> Back</a>

                <h3>Tv Show: {{ucfirst($tvshow->name)}} Season {{$seasonNumber}} Episode {{$episodeNr}}</h3>

                <form class="uk-form" method="post" action="{{action('AdminTvShowSeasonController@updateEpisode')}}" enctype="multipart/form-data">
                    @csrf
                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Title:</label>
                        <input type="text" placeholder="Episode Title" class="uk-width-1-1" name="title" value="{{$episode->title}}">

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Air Date:</label>
                        <input type="date" placeholder="Release Date" class="uk-width-1-1" name="air_date" value="{{$episode->air_date}}">

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Overview:</label>
                        <textarea class="uk-width-1-1" rows="5" placeholder="Add Overview" name="overview">{{$episode->overview}}</textarea>

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Vote Average:</label>
                        <input type="text" placeholder="Vote Average" class="uk-width-1-1" name="vote_average" value={{$episode->vote_average}}>

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Video:</label>
                        <input type="text" placeholder="https://www.youtube.com/embed/ZsBO4b3tyZg" class="uk-width-1-1" name="video" value="{{$episode->video}}">

                    </div>

                    <input type="hidden" name="poster" value="{{$episode->poster}}">
                    <input type="hidden" name="tvshow_id_local" value="{{$tvshow->id}}">
                    <input type="hidden" name="episode_number" value="{{$episodeNr}}">
                    <input type="hidden" name="season_id" value="{{$seasonNumber}}">
                    <input type="hidden" name="episode_id" value="{{$episode->id}}">

                    <div class="space"></div>

                    <div class="uk-form-row">
                        <button class="uk-button uk-button-primary uk-float-left" type="submit">Update</button>
                    </div>


                </form>

                    <form class="uk-form uk-float-right delete-form" method="get" action="{{route('deleteEpisode', $episode->id)}}">
                        @csrf

                        <button class="uk-button uk-button-danger" type="submit">Delete</button>
                    </form>

            </div>

            <div class="uk-width-3-10">

                <img src="https://image.tmdb.org/t/p/w500{{$episode->poster}}">
                <div class="space"></div>
                Episode: {{$episodeNr}}
                @include('includes.errors')

            </div>

        </div>

    </div>

    </div>
    </div>
    </div>
    <!--     ./ Main Section   -->


@endsection