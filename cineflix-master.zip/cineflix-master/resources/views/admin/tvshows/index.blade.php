@extends('layouts.admin')

@section('content')


    <div id="tm-right-section" class="uk-width-large-8-10 uk-width-medium-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">

        @if(Session::has('status'))

            <div class="uk-grid">
                <div class="uk-width-1-1">
                    <div class="uk-alert uk-alert-success" data-uk-alert>
                        <a href="" class="uk-alert-close uk-close"></a>
                        <p>{{session('status')}}</p>
                    </div>
                </div>
            </div>

        @endif

            @if(Session::has('status-warning'))

                <div class="uk-grid">
                    <div class="uk-width-1-1">
                        <div class="uk-alert uk-alert-warning" data-uk-alert>
                            <a href="" class="uk-alert-close uk-close"></a>
                            <p>{{session('status-warning')}}</p>
                        </div>
                    </div>
                </div>

            @endif
        <div class="uk-grid">

            <div class="uk-width-1-2">
                {{--<a href="{{route('admin.tvshows.create')}}"><button class="uk-button uk-button-primary" type="button">Add Movie</button></a>--}}
                <button data-uk-modal="{target:'#import'}" class="uk-button uk-button-danger" type="button">Import</button>
            </div>

            <div class="uk-width-1-2">

                <form class="uk-search uk-margin-small-top uk-margin-left uk-hidden-small" method="get" action="/admin/tvshows/search">
                    <input class="uk-search-field" type="search" placeholder="Search..." autocomplete="off" name="q">
                    <div class="uk-dropdown uk-dropdown-flip uk-dropdown-search" aria-expanded="false"></div>
                </form>

            </div>

        </div>

        <div class="space"></div>

        <div id="import" class="uk-modal">
            <div class="uk-modal-dialog">
                <a class="uk-modal-close uk-close"></a>
                <div class="uk-modal-header"><h2>Import</h2></div>

                <form method="post" action="{{action('AdminTvshowsController@import')}}">
                    @csrf

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">TheMovieDB ID:</label>
                        <input type="number" placeholder="" class="uk-width-1-1" name="import" required>

                    </div>

                    <div class="uk-form-row">
                        <button class="uk-button uk-button-primary uk-float-left" type="submit">Import</button>
                    </div>

                </form>

            </div>
        </div>

        <div class="uk-grid">
            <div class="uk-width-1-1">

                @if($tvshows)

                    <table class="uk-table uk-table-hover uk-table-striped uk-table-condensed">
                        <p>All Tv Shows</p>
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Poster</th>
                            <th>Title</th>
                            <th>Release Date</th>
                            <th>Rating</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($tvshows as $tvshow)
                            <tr>
                                <td>{{$tvshow->id}}</td>
                                <td><img width="30" src="https://image.tmdb.org/t/p/w500{{$tvshow->poster}}" alt="Image" ></td>
                                <td>{{$tvshow->name}}</td>
                                <td>{{$tvshow->first_air_date}}</td>
                                <td>{{$tvshow->vote_average}}</td>
                                <td><a href="{{route('admin.tvshows.edit', $tvshow->id)}}"><i class="uk-icon-edit"></i></a></td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                @else
                    <h4>No Tv Shows</h4>
                @endif


            </div>
        </div>

        <div class="space"></div>

        <div class="uk-width-medium-1-2 uk-container-center">
            {{$tvshows->links('vendor.pagination.default')}}
        </div>

    </div>

    </div>
    </div>
    </div>
    <!--     ./ Main Section   -->

@endsection