@extends('layouts.admin')

@section('content')

    <div id="tm-right-section" class="uk-width-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">
        <div class="uk-grid">

            @if(Session::has('status'))

                <div class="uk-grid">
                    <div class="uk-width-1-1">
                        <div class="uk-alert uk-alert-success" data-uk-alert>
                            <a href="" class="uk-alert-close uk-close"></a>
                            <p>{{session('status')}}</p>
                        </div>
                    </div>
                </div>

            @endif

            <h2>TV Show: {{ucfirst($tvshow->name)}} Season {{$seasonNumber}}</h2>

                @if(count($episodes) > 0)

                <table class="uk-table">
                    <thead>
                    <tr>
                        <th>Nr.</th>
                        <th>Title</th>
                        <th>Air Date</th>
                        <th>Vote Average</th>
                        <th>Created at</th>
                        <th>Updated at</th>
                    </tr>
                    </thead>
                    <tbody>
                        @foreach($episodes as $episode)

                            <tr>
                                <td>{{$episode->episode_number}}</td>
                                <td>{{$episode->title}}</td>
                                <td>{{$episode->air_date}}</td>
                                <td>{{$episode->vote_average}}</td>
                                <td>{{$episode->created_at->diffForHumans()}}</td>
                                <td>{{$episode->updated_at->diffForHumans()}}</td>
                                <td><a href="{{route('edit_episode', ['slug'=>$tvshow->slug, 'number'=> $seasonNumber, 'episodeNumber'=>$episode->episode_number])}}"><i class="uk-icon-edit"></a></td>
                            </tr>

                        @endforeach
                    </tbody>
                </table>

                @else

                    <p>No Episodes</p>

                @endif

        </div>

    </div>

    </div>
    </div>
    </div>
    <!--     ./ Main Section   -->


@endsection