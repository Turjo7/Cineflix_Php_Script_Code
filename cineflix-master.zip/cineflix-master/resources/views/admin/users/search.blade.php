@extends('layouts.admin')

@section('content')

    <div id="tm-right-section" class="uk-width-large-8-10 uk-width-medium-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">


        <div class="uk-grid">

            <div class="uk-width-1-2">
                <a href="{{route('admin.users.create')}}"><button class="uk-button uk-button-primary" type="button">Add User</button></a>
            </div>

            <div class="uk-width-1-2">

                <form class="uk-search uk-margin-small-top uk-margin-left uk-hidden-small" method="get" action="/admin/users/search">
                    <input class="uk-search-field" type="search" placeholder="Search..." autocomplete="off" name="q">
                    <div class="uk-dropdown uk-dropdown-flip uk-dropdown-search" aria-expanded="false"></div>
                </form>

            </div>

        </div>

        @if(Session::has('status'))

            <div class="uk-grid">
                <div class="uk-width-1-1">
                    <div class="uk-alert uk-alert-success" data-uk-alert>
                        <a href="" class="uk-alert-close uk-close"></a>
                        <p>{{session('status')}}</p>
                    </div>
                </div>
            </div>

        @endif

        <div class="uk-grid">
            <div class="uk-width-1-1">

                <table class="uk-table uk-table-hover uk-table-striped uk-table-condensed">
                    <p>All Users</p>

                    <div class="space"></div>

                    <p>You have searched: "{{$input}}"</p>

                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Email</th>
                        <th>Created</th>
                        <th>Updated</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($results as $result)
                        <tr>
                            <td>{{$result->id}}</td>
                            <td>{{$result->name}}</td>
                            <td>{{$result->role->name}}</td>
                            <td>{{$result->email}}</td>
                            <td>{{$result->created_at->diffForHumans()}}</td>
                            <td>{{$result->updated_at->diffForHumans()}}</td>
                            <td><a href="{{route('admin.users.edit', $result->id)}}"><i class="uk-icon-edit"></a></td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>

            </div>
        </div>

        <div class="space"></div>

        <div class="uk-width-medium-1-2 uk-container-center">
            {{$results->links('vendor.pagination.default')}}
        </div>

    </div>

    </div>
    </div>
    </div>
    <!--     ./ Main Section   -->

@endsection

