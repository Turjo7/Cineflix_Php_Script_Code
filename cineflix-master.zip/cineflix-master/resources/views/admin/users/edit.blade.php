@extends('layouts.admin')

@section('content')

    @extends('layouts.admin')

@section('content')


    <div id="tm-right-section" class="uk-width-large-8-10 uk-width-medium-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">


        <div class="uk-grid">

            <div class="uk-width-1-1">
                <a href="{{route('admin.users.index')}}"><button class="uk-button uk-button-primary" type="button"><i class="uk-icon-arrow-left"></i> Go Back</button></a>
            </div>

        </div>

        <div class="uk-grid">

            <div class="uk-width-7-10">

                <form class="uk-form" method="post" action="{{action('AdminUsersController@update' , $user->id)}}" enctype="multipart/form-data">
                    @csrf
                    @method('patch')
                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Name:</label>
                        <input type="text" placeholder="Username" class="uk-width-1-1" name="name" value="{{$user->name}}">

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Role:</label>
                        <select class="uk-form" name="role_id">

                            <option value selected="selected">Select Role</option>
                            @foreach($roles as $role)
                                <option value="{{$role->id}}">{{$role->name}}</option>
                            @endforeach
                        </select>

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Email:</label>
                        <input type="email" placeholder="Email" class="uk-width-1-1" name="email" value="{{$user->email}}">

                    </div>

                    <div class="uk-form-row">

                        <label class="uk-form-label uk-width-1-1" for="">Password:</label>
                        <input type="password" placeholder="Password" class="uk-width-1-1" name="password">

                    </div>

                    <div class="uk-form-row">
                        <button class="uk-button uk-button-primary" type="submit">Update</button>
                    </div>


                </form>

                <form class="uk-form uk-float-right delete-form" method="post" action="{{action('AdminUsersController@destroy', $user->id)}}">
                    @csrf
                    @method('delete')
                    <div class="uk-form-row">
                        <button class="uk-button uk-button-danger" type="submit">Delete</button>
                    </div>
                </form>

            </div>

            <div class="uk-width-3-10">
                @include('includes.errors')
            </div>

        </div>



    </div>

    </div>
    </div>
    </div>
    <!--     ./ Main Section   -->

@endsection

@endsection