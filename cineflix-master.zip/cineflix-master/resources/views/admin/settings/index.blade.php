@extends('layouts.admin')

@section('content')

    <div id="tm-right-section" class="uk-width-large-8-10 uk-width-medium-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">

        @if(Session::has('status'))

            <div class="uk-grid">
                <div class="uk-width-1-1">
                    <div class="uk-alert uk-alert-success" data-uk-alert>
                        <a href="" class="uk-alert-close uk-close"></a>
                        <p>{{session('status')}}</p>
                    </div>
                </div>
            </div>

        @endif

        <div class="space"></div>

            <div class="space"></div>
            <div class="space"></div>

            <div class="uk-width-medium-1-1 uk-row-first">

                <div class="uk-grid">
                    <div class="uk-width-medium-3-10">

                        <ul class="uk-tab uk-tab-left" data-uk-tab="{connect:'#tab-left-content'}">
                            <li class="uk-active" aria-expanded="true"><a href="#">General</a></li>
                            <li aria-expanded="false" class=""><a href="#">SEO</a></li>
                            <li aria-expanded="false" class=""><a href="#">Social</a></li>
                            <li aria-expanded="false" class=""><a href="#">TMDB API</a></li>
                        </ul>

                    </div>
                    <div class="uk-width-medium-7-10">

                        <ul id="tab-left-content" class="uk-switcher">
                            <li class="uk-active" aria-hidden="false">

                                <form class="uk-form" method="post" action="{{action('AdminSettingsController@update', $setting->id)}}" enctype="multipart/form-data">
                                    @csrf
                                    @method('PATCH')
                                    <h4>General</h4>
                                    <p>Configure general site settings</p>

                                    <div class="space"></div>

                                    <div class="uk-form-row">
                                        <label class="uk-form-label" for="form-s-s">Select Logo Type</label>
                                        <div class="uk-form-controls">
                                            <select class="uk-width-1-1" id="form-s-s" name="logo_type">

                                                <option selected value="{{$setting->logo_type}}">Select Type</option>
                                                <option value="text">Text Logo</option>
                                                <option value="image">Image Logo</option>

                                            </select>
                                        </div>
                                    </div>

                                    <div class="uk-form-row">
                                        <label class="uk-form-label" for="form-s-s">Display Ads</label>
                                        <div class="uk-form-controls">
                                            <select class="uk-width-1-1" id="form-s-s" name="display_ads">

                                                <option selected value="{{$setting->display_ads}}">Select</option>
                                                <option value="1">Yes</option>
                                                <option value="0">No</option>

                                            </select>
                                        </div>
                                    </div>

                                    <div class="uk-form-row">
                                        <label class="uk-form-label" for="form-s-s">Watch Movies Requirement</label>
                                        <div class="uk-form-controls">
                                            <select class="uk-width-1-1" id="form-s-s" name="watch">

                                                <option selected value="{{$setting->watch}}">Select</option>
                                                <option value="1">Authenticated User</option>
                                                <option value="0">All Users</option>

                                            </select>
                                        </div>
                                    </div>

                                    <div class="uk-form-row">

                                        <label class="uk-form-label" for="">Text Logo</label>
                                        <div class="uk-width-1-1">
                                            <input type="text" placeholder="CINEFLIX" class="uk-width-1-1" name="textlogo" value="{{strtoupper($setting->textlogo)}}">
                                        </div>

                                    </div>

                                    <div class="uk-form-row">

                                        <label class="uk-form-label" for="url">Site URL</label>
                                        <div class="uk-width-1-1">
                                            <input type="text" placeholder="https://1devlab.com" class="uk-width-1-1" name="url" value="{{$setting->url}}">
                                        </div>

                                    </div>

                                    <div class="uk-form-row">

                                        <label class="uk-form-label" for="email">Email</label>
                                        <div class="uk-width-1-1">
                                            <input type="text" placeholder="Your website email" class="uk-width-1-1" name="email" value="{{$setting->email}}">
                                        </div>

                                    </div>

                                    <div class="uk-form-row">

                                        <label class="uk-form-label" for="copyright">Copyright Text</label>
                                        <div class="uk-width-1-1">
                                            <input type="text" placeholder="© 2019 CINEFLIX - Watch Movies Online" class="uk-width-1-1" name="copyright" value="{{$setting->copyright}}">
                                        </div>

                                    </div>

                                    <div class="uk-form-row">

                                        <label class="uk-form-label" for="copyright">Google Analytics</label>
                                        <div class="uk-width-1-1">
                                            <textarea class="uk-width-1-1" rows="5" placeholder="..." name="analytics">{{$setting->analytics}}</textarea>
                                        </div>

                                    </div>

                                    <div class="uk-form-row">

                                        <label class="uk-form-label" for="copyright">Upload image logo</label>
                                        <div class="uk-width-1-1">
                                            <input type="file" name="logo">
                                        </div>

                                    </div>

                                    <div class="uk-form-row">
                                        <button class="uk-button uk-button-primary" type="submit">Save</button>
                                    </div>

                                    </form>
                            </li>
                            <li aria-hidden="true" class="">

                                <form class="uk-form" method="post" action="{{action('AdminSettingsController@update', $setting->id)}}">
                                    @csrf
                                    @method('PATCH')
                                    <h4>SEO</h4>
                                    <p>Configure SEO site settings</p>

                                    <div class="space"></div>

                                    <div class="uk-form-row">

                                        <label class="uk-form-label" for="">Site Title</label>
                                        <div class="uk-width-1-1">
                                            <input type="text" placeholder="" class="uk-width-1-1" name="site_title" value="{{$setting->site_title}}">
                                        </div>

                                    </div>

                                    <div class="uk-form-row">

                                        <label class="uk-form-label" for="copyright">Site Description</label>
                                        <div class="uk-width-1-1">
                                            <textarea class="uk-width-1-1" rows="5" placeholder="..." name="description">{{$setting->description}}</textarea>
                                        </div>

                                    </div>

                                    <div class="uk-form-row">

                                        <label class="uk-form-label" for="">Site Keywords</label>
                                        <div class="uk-width-1-1">
                                            <input type="text" placeholder="" class="uk-width-1-1" name="keywords" value="{{$setting->keywords}}">
                                        </div>

                                    </div>


                                    <div class="uk-form-row">
                                        <button class="uk-button uk-button-primary" type="submit">Save</button>
                                    </div>

                                    </form>

                            </li>
                            <li aria-hidden="true" class="">

                                <form class="uk-form" method="post" action="{{action('AdminSettingsController@update', $setting->id)}}">
                                    @csrf
                                    @method('PATCH')
                                    <h4>Social</h4>
                                    <p>Configure social site settings</p>

                                    <div class="space"></div>

                                    <div class="uk-form-row">

                                        <label class="uk-form-label" for="">Facebook</label>
                                        <div class="uk-width-1-1">
                                            <input type="text" placeholder="" class="uk-width-1-1" name="facebook" value="{{$setting->facebook}}">
                                        </div>

                                    </div>

                                    <div class="uk-form-row">

                                        <label class="uk-form-label" for="">Twitter</label>
                                        <div class="uk-width-1-1">
                                            <input type="text" placeholder="" class="uk-width-1-1" name="twitter" value="{{$setting->twitter}}">
                                        </div>

                                    </div>

                                    <div class="uk-form-row">

                                        <label class="uk-form-label" for="">Instagram</label>
                                        <div class="uk-width-1-1">
                                            <input type="text" placeholder="" class="uk-width-1-1" name="instagram" value="{{$setting->instagram}}">
                                        </div>

                                    </div>

                                    <div class="uk-form-row">

                                        <label class="uk-form-label" for="">Pinterest</label>
                                        <div class="uk-width-1-1">
                                            <input type="text" placeholder="" class="uk-width-1-1" name="pinterest" value="{{$setting->pinterest}}">
                                        </div>

                                    </div>



                                    <div class="uk-form-row">
                                        <button class="uk-button uk-button-primary" type="submit">Save</button>
                                    </div>

                                </form>

                            </li>
                            <li aria-hidden="true">

                                <form class="uk-form" method="post" action="{{action('AdminSettingsController@update', $setting->id)}}">
                                    @csrf
                                    @method('PATCH')
                                    <h4>TMDB API</h4>
                                    <p>Configure tmdb site settings</p>

                                    <div class="space"></div>

                                    <div class="uk-form-row">

                                        <label class="uk-form-label" for="">TMDB API</label>
                                        <div class="uk-width-1-1">
                                            <input type="text" placeholder="" class="uk-width-1-1" name="tmdb" value="{{$setting->tmdb}}">
                                        </div>

                                    </div>


                                    <div class="uk-form-row">
                                        <button class="uk-button uk-button-primary" type="submit">Save</button>
                                    </div>

                                </form>

                            </li>
                        </ul>

                    </div>
                </div>

            </div>

    </div>

    </div>
    </div>
    </div>
    <!--     ./ Main Section   -->

@endsection