@extends('layouts.admin')

@section('content')

    <div id="tm-right-section" class="uk-width-large-8-10 uk-width-medium-7-10"  data-uk-scrollspy="{cls:'uk-animation-fade', target:'img'}">

        <div class="uk-grid">
            <div class="uk-width-1-1">

                <table class="uk-table uk-table-hover uk-table-striped uk-table-condensed">
                    <p>All Searches</p>
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Created</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($searches as $search)
                        <tr>
                            <td>{{$search->id}}</td>
                            <td>{{$search->title}}</td>
                            <td>{{$search->created_at->diffForHumans()}}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>

            </div>
        </div>

        <div class="space"></div>

        <div class="uk-width-medium-1-2 uk-container-center">
            {{$searches->links('vendor.pagination.default')}}
        </div>

    </div>

    </div>
    </div>
    </div>
    <!--     ./ Main Section   -->

@endsection