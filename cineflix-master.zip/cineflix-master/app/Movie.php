<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;

class Movie extends Model
{
    use Sluggable;

    public function sluggable()
    {
        return [
            'slug' => [
                'source' => 'title'
            ]
        ];
    }

    protected $fillable = [
        'title',
        'budget',
        'homepage',
        'overview',
        'poster',
        'language',
        'revenue',
        'runtime',
        'release_date',
        'vote_average',
        'trailer',
        'slug',
        'imported'
    ];

    public function categories(){
        return $this->belongsToMany('App\Category');
    }

    public function reviews() {
        return $this->hasMany('App\Review');
    }

    public function videos() {
        return $this->belongsToMany('App\Video');
    }

    public function credits() {
        return $this->belongsToMany('App\MovieCredit');
    }

}
