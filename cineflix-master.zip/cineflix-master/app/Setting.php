<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    protected $fillable = [

        'url',
        'logo',
        'textlogo',
        'logo_type',
        'site_title',
        'email',
        'copyright',
        'display_ads',
        'watch',
        'analytics',
        'keywords',
        'description',
        'facebook',
        'twitter',
        'instagram',
        'pinterest',
        'faq',
        'terms',
        'privacy',
        'contact',
        'tmdb'

    ];
}
