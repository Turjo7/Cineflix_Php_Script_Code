<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $table = 'categories';

    protected $fillable = [
        'name'
    ];

    public function movies() {
        return $this->hasMany('App\Movie', 'category_id');
    }

    public function tvshows() {
        return $this->hasMany('App\Tvshow', 'category_id');
    }



}
