<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CategoryPivot extends Model
{
    protected $table = 'category_movie';

    protected $fillable = [
        'category_id',
        'movie_id'
    ];

    public function movies() {
        return $this->belongsToMany('App\Movie');
    }

    public function categories() {
        return $this->belongsToMany('App\Category', 'category_movie');
    }
}
