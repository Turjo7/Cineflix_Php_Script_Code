<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Favorite extends Model
{
    protected $fillable = [
        'user_id',
        'movie_title',
        'movie_slug',
        'movie_poster'
    ];

    public function users(){
        return $this->belongsTo('App\User');
    }
}
