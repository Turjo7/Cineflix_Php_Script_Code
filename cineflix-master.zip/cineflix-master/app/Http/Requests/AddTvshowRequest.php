<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AddTvshowRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name'=>'required',
            'overview'=>'required',
            'first_air_date'=>'required',
            'homepage'=>'required',
            'vote_average'=>'required',
            'trailer'=>'required',
            'categories_id'=>'required'
        ];
    }
}
