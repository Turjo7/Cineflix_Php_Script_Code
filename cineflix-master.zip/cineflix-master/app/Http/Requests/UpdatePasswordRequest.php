<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdatePasswordRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'current-password'=>'required',
            'password'=>'required',
            'confirm-password'=>'required|same:password'
        ];
    }

    public function messages()
    {
        return [

            'confirm-password.same:password'=>'Confirm password and password field must match!',
            'current-password'=>'Baga ba'

        ];
    }

}
