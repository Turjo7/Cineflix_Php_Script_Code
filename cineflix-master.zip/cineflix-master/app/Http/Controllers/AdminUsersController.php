<?php

namespace App\Http\Controllers;

use App\Category;
use App\Http\Requests\AddUserRequest;
use App\Http\Requests\EditUserRequest;
use App\Role;
use App\Setting;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class AdminUsersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users      = User::orderBy('id','desc')->paginate(10);
        $setting    = Setting::whereId(1)->first();
        $categories = Category::orderBy('name')->get();

        return view('admin.users.index', compact('users', 'setting', 'categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        $roles      = Role::all();

        $setting    = Setting::whereId(1)->first();

        $categories = Category::orderBy('name')->get();

        return view('admin.users.create', compact('roles', 'setting', 'categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AddUserRequest $request)
    {
        $input = $request->all();

        $input['password'] = bcrypt($request->password);

        User::create($input);

        Session::flash('status', 'New user has been added');

        return redirect('admin/users');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = User::findOrFail($id);

        $roles = Role::all();

        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        return view('admin.users.edit', compact('user', 'roles', 'categories', 'setting'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(EditUserRequest $request, $id)
    {
        $user = User::findOrFail($id);

        if(trim($request->password == '')) {
            $input = $request->except('password');
        } else {
            $input = $request->all();
            $input['password'] = bcrypt($request->password);
        }

        $user->update($input);

        Session::flash('status', 'User has been updated succesfully!');

        return redirect('admin/users');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = User::findOrFail($id);

        $user->delete();

        Session::flash('status', 'User has been deleted successfully!');

        return redirect('admin/users');
    }

    public function search(Request $request) {

        $input = $request->q;

        if(!$input) {
            return redirect('/admin/users');
        }

        $results = User::where('name', 'LIKE', '%'.$input.'%')->orWhere('email', 'LIKE', '%'.$input.'%')->orderBy('id','desc')->paginate(10);

        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        return view('admin.users.search', compact('input', 'results', 'categories', 'setting'));

    }

}
