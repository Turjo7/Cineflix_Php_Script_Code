<?php

namespace App\Http\Controllers;

use App\Category;
use App\Http\Requests\ReviewRequest;
use App\Setting;
use App\TvShowReview;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class AdminTvShowReviewController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $reviews    = TvShowReview::orderBy('id','desc')->with('tvshows')->paginate(10);

        $setting    = Setting::whereId(1)->first();

        $categories = Category::orderBy('name')->get();

        return view('admin.tvshowreviews.index', compact('reviews', 'setting', 'categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $review     = TvShowReview::findOrFail($id);

        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        return view('admin.tvshowreviews.edit', compact('review', 'categories', 'setting'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ReviewRequest $request, $id)
    {
        $input = $request->all();

        TvShowReview::whereId($id)->first()->update($input);

        Session::flash('status', 'A new review was approved!');

        return redirect('admin/tvshowreviews');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
