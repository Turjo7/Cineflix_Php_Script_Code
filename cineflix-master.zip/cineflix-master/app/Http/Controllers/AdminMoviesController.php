<?php

namespace App\Http\Controllers;

use App\Category;
use App\Http\Requests\AddMovieRequest;
use App\Http\Requests\ImportRequest;
use App\Movie;
use App\MovieCredit;
use App\Setting;
use App\User;
use App\Video;
use App\VideoPivot;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Tmdb\Exception\TmdbApiException;
use Tmdb\Laravel\Facades\Tmdb;

class AdminMoviesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
      $movies     = Movie::orderBy('id','desc')->paginate(10);

      $categories = Category::orderBy('name')->get();

      $setting    = Setting::whereId(1)->first();

      return view('admin.movies.index', compact('movies', 'categories', 'setting'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        return view('admin.movies.create', compact('categories', 'setting'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AddMovieRequest $request)
    {

        $movie = new Movie();
        $movie->title = $request->title;
        $movie->release_date = $request->release_date;
        $movie->overview = $request->overview;
        $movie->budget = $request->budget;
        $movie->homepage = $request->homepage;
        $movie->language = $request->language;
        $movie->revenue = $request->revenue;
        $movie->runtime = $request->runtime;
        $movie->vote_average = $request->vote_average;
        $movie->trailer = $request->trailer;

        if($file = $request->file('poster')) {

            $name = time() . $file->getClientOriginalName();
            $file->move('img', $name);
            $movie->poster = $name;

        } else {

            $movie->poster = $request->poster;

        }

        $movie->imported = $request->imported;
        $movie->save();
        $movie->categories()->attach($request->categories_id);

        $video = new Video();
        $video->name = $request->video;
        $video->save();

        $movie->videos()->attach($video->id);

        $credits = Tmdb::getMoviesApi()->getCredits($request->tmdbId);

        foreach($credits['cast'] as $cast) {

            $movieCredit = new MovieCredit();
            $movieCredit->movie_id = $movie->id;
            $movieCredit->name = $cast['name'];
            $movieCredit->image = $cast['profile_path'];
            $movieCredit->character = $cast['character'];
            $movieCredit->save();

        }


        Session::flash('status', 'New Movie was added successfully!');

        return redirect('admin/movies');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        try{

            $movie      = Tmdb::getMoviesApi()->getMovie($id);

        } catch (TmdbApiException $e){

            if (TmdbApiException::STATUS_RESOURCE_NOT_FOUND == $e->getCode()) {

                Session::flash('status-warning', 'No movie found for this ID!');

                return redirect()->route('admin.movies.index');

            }

        }

        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        return view('admin.movies.show', compact('movie', 'categories', 'setting'));
    }

    public function import(ImportRequest $request)
    {

        $input = $request->all();

        $id = $input['import'];

        return redirect()->route('admin.movies.show', $id);

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $movie      = Movie::findOrFail($id);

        $categories = Category::orderBy('name')->get();

        $video      = VideoPivot::where('movie_id', $id)->first();

        $setting    = Setting::whereId(1)->first();

        return view('admin.movies.edit', compact('movie', 'categories', 'video', 'setting'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(AddMovieRequest $request, $id)
    {
        $input = $request->all();

        Movie::whereId($id)->first()->update($input);

        Video::whereId($request->video_id)->first()->update(['name'=>$request->video]);

        Session::flash('status', 'The Movie ' . $input['title'] . ' has been updated');

        return redirect('admin/movies');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        $movie = Movie::findOrFail($id);

        $movie->delete();

        Session::flash('status', 'A move was deleted!');

        return redirect('admin/movies');
    }

    public function deleteMovies(Request $request){

        if(empty($request->checkBoxArray)) {

            $movies = Movie::findOrFail($request->checkBoxArray);

            foreach($movies as $movie) {
                $movie->delete();
            }
        } else {
            Session::flash('status', 'Select a movie to delete it.');
        }



       return redirect()->back();
    }

    public function search(Request $request) {

        $input = $request->q;

        if(!$input) {
            return redirect('/admin/movies');
        }

        $results = Movie::where('title', 'LIKE', '%'.$input.'%')->orWhere('overview', 'LIKE', '%'.$input.'%')->orderBy('id','desc')->paginate(10);

        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        return view('admin.movies.search', compact('results', 'categories', 'setting', 'input'));

    }

}
