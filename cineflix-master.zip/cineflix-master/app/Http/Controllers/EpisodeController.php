<?php

namespace App\Http\Controllers;

use App\Category;
use App\Episode;
use App\Http\Requests\AddEpisodeRequest;
use App\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Tmdb\Laravel\Facades\Tmdb;

class EpisodeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AddEpisodeRequest $request)
    {
        $input = $request->all();

        $episode = new Episode();

        $episode->tvshow_id = $request->tvshow_id_local;
        $episode->season_id = $request->season_id;
        $episode->episode_number = $request->episode_number;
        $episode->title = $request->title;
        $episode->overview = $request->overview;
        $episode->poster = $request->poster;
        $episode->vote_average = $request->vote_average;
        $episode->air_date = $request->air_date;
        $episode->video = $request->video;
        $episode->save();

        Session::flash('status', 'New episode for season ' . $episode->season_id . ' was added');

        return redirect()->route('admin.tvshows.edit', $episode->tvshow_id);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        $tvshow_id  = $_GET['tvshow_id'];

        $season_id  = $_GET['season_id'];

        $tvshow_id_local = $_GET['tvshow_id_local'];

        $episode    = Tmdb::getTvEpisodeApi()->getEpisode($tvshow_id, $season_id, $id);

        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        if(!$episode) {
            return redirect('/admin/tvshows');
        }

        return view('admin.episodes.show', compact('episode', 'categories', 'setting', 'tvshow_id_local', 'season_id'));

    }

    public function import(Request $request) {

        $input = $request->all();

        $id = $input['number'];

        $tvshow_id = $input['tvshow_id'];

        $tvshow_id_local = $input['tvshow_id_local'];

        $season_id = $input['season_id'];

        $checkIfExists = Episode::where('episode_number', $id)->where('season_id', $season_id)->where('tvshow_id', $tvshow_id_local)->first();

        if($checkIfExists == true) {

            Session::flash('status', 'This episode is already imported!');

            return redirect()->route('admin.tvshows.edit', $tvshow_id_local);
        }

        return redirect()->route('admin.episodes.show', ['id'=>$id, 'tvshow_id'=>$tvshow_id, 'tvshow_id_local'=>$tvshow_id_local, 'season_id'=>$season_id]);


    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
