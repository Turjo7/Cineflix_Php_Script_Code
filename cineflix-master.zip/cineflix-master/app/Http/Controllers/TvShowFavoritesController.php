<?php

namespace App\Http\Controllers;

use App\Http\Requests\AddTvShowFavorite;
use App\TvFavorite;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class TvShowFavoritesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AddTvShowFavorite $request)
    {
        $user = Auth::user();

        $userFavorites = TvFavorite::where('user_id', $user->id)->where('tvshow_slug', $request->tvshow_slug)->first();

        if($userFavorites == true) {

            Session::flash('status-warning', 'The Tv Show ' . $request->tvshow_title . ' is already in your list!');

            return redirect()->route('tvshow_detail', $request->tvshow_slug);

        }

        $favorite = new TvFavorite();

        $favorite->user_id = $request->user_id;
        $favorite->tvshow_title = $request->tvshow_title;
        $favorite->tvshow_slug = $request->tvshow_slug;
        $favorite->tvshow_poster = $request->tvshow_poster;
        $favorite->save();

        Session::flash('status', 'The Tv Show ' . $favorite->tvshow_title . ' was added to your favorite list!');

        return redirect()->route('tvshow_detail', $favorite->tvshow_slug);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        TvFavorite::where('user_id', $request->user_id)->where('tvshow_slug', $request->tvshow_slug)->first()->delete();

        Session::flash('status-warning', 'This Tv Show was removed from your favorite list!');

        return redirect()->back();
    }
}
