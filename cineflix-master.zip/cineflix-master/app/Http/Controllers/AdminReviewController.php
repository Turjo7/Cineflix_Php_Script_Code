<?php

namespace App\Http\Controllers;

use App\Category;
use App\Http\Requests\ReviewRequest;
use App\Review;
use App\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class AdminReviewController extends Controller
{
    public function index()
    {
        $reviews    = Review::orderBy('id','desc')->with('movies')->paginate(10);

        $setting    = Setting::whereId(1)->first();

        $categories = Category::orderBy('name')->get();

        return view('admin.reviews.index', compact('reviews', 'setting', 'categories'));
    }

    public function edit($id) {

        $review     = Review::findOrFail($id);

        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        return view('admin.reviews.edit', compact('review', 'categories', 'setting'));
    }

    public function update(ReviewRequest $request, $id) {

        $input = $request->all();

        Review::whereId($id)->first()->update($input);

        Session::flash('status', 'A new review was approved!');

        return redirect('admin/reviews');

    }


}
