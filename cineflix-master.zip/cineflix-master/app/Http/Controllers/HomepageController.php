<?php

namespace App\Http\Controllers;

use App\Ad;
use App\Category;
use App\CategoryPivot;
use App\Episode;
use App\Favorite;
use App\Movie;
use App\MovieCredit;
use App\Review;
use App\Search;
use App\Setting;
use App\TvFavorite;
use App\Tvshow;
use App\TvShowCredit;
use App\TvShowReview;
use App\TvshowSeason;
use App\Video;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Kevinrob\GuzzleCache\CacheEntry;
use Tmdb\Api\Tv;

class HomepageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $allmovies  = Movie::orderBy('id', 'desc')->limit(6)->get();

        $tvshows    = Tvshow::orderBy('id', 'desc')->limit(6)->get();

        $cmovies    = Movie::whereHas('categories', function($q) {$q->where('name', 'comedy');})->limit(6)->get();

        $smovies    = Movie::whereHas('categories', function($q) {$q->where('name', 'superhero');})->limit(6)->get();

        $amovies    = Movie::whereHas('categories', function($q) {$q->where('name', 'adventure');})->limit(6)->get();

        $hmovies    = Movie::whereHas('categories', function($q) {$q->where('name', 'horror');})->limit(6)->get();

        $anmovies   = Movie::whereHas('categories', function($q) {$q->where('name', 'animation');})->limit(6)->get();

        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        $ad         = Ad::whereId(1)->first();

        return view('welcome', compact('allmovies','tvshows', 'categories', 'cmovies', 'smovies', 'amovies', 'hmovies', 'anmovies', 'setting', 'ad'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function movie($slug) {

        $movie      = Movie::where('slug', $slug)->first();

        $credits    = MovieCredit::where('movie_id', $movie->id)->get();

        $categories = Category::orderBy('name')->get();

        $videos     = Video::all();

        $reviews    = Review::whereMovieId($movie->id)->orderBy('id','desc')->whereIsActive(1)->paginate(5);

        $setting    = Setting::whereId(1)->first();

        $ad         = Ad::whereId(1)->first();

        $relates    = Movie::whereHas('categories', function($q) use($movie) {$q->where('name', $movie->categories->pluck('name'));})->where('id', '!=', $movie->id)->take(12)->get();

        if(Auth::check()){

            $user = Auth::user();

            $isInList    = Favorite::where('user_id', $user->id)->where('movie_slug', $movie->slug)->first();

            if($isInList == true) {
                $isInList = 1;
            }

        } else {$user = ""; $isInList = 0;}

        return view('movie', compact('movie', 'categories', 'reviews', 'user', 'videos', 'setting', 'ad', 'relates', 'isInList', 'credits'));

    }


    public function tvshow($slug) {

        $tvshow      = Tvshow::where('slug', $slug)->first();

        $seasons     = TvshowSeason::where('tvshow_id', $tvshow->id)->orderBy('number', 'asc')->get();

        $credits    = TvShowCredit::where('tvshow_id', $tvshow->id)->get();

        $categories  = Category::orderBy('name')->get();

        $reviews     =  TvShowReview::where('tvshow_id',$tvshow->id)->orderBy('id','desc')->whereIsActive(1)->paginate(5);

        $setting     = Setting::whereId(1)->first();

        $ad          = Ad::whereId(1)->first();

        $relates     = Tvshow::whereHas('categories', function($q) use($tvshow) {$q->where('name', $tvshow->categories->pluck('name'));})->where('id', '!=', $tvshow->id)->take(12)->get();

        if(Auth::check()){

            $user = Auth::user();

            $isInList    = TvFavorite::where('user_id', $user->id)->where('tvshow_slug', $tvshow->slug)->first();

            if($isInList == true) {
                $isInList = 1;
            }

        } else {$user = ""; $isInList = 0;}

        return view('tvshow', compact('tvshow', 'categories', 'reviews', 'user', 'setting', 'ad', 'relates', 'seasons', 'isInList', 'credits'));

    }

    public function season($slug, $number) {


        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        $ad         = Ad::whereId(1)->first();

        $tvshow     = Tvshow::where('slug', $slug)->first();

        $episodes   = Episode::where('tvshow_id', $tvshow->id)->where('season_id', $number)->get();

        $seasonNumber = $number;

        $relates     = Tvshow::whereHas('categories', function($q) use($tvshow) {$q->where('name', $tvshow->categories->pluck('name'));})->where('id', '!=', $tvshow->id)->get();


        return view('season', compact('categories', 'setting', 'ad', 'tvshow', 'relates', 'episodes', 'seasonNumber'));

    }

    public function search(Request $request) {

        $input = $request->q;

        if(!$input) {
            return redirect('/');
        }

        //Looking for Movies
        $results = Movie::where('title', 'LIKE', '%'.$input.'%')->orWhere('overview', 'LIKE', '%'.$input.'%')->get();
        //Looking for Tv Shows
        $tvResults = Tvshow::where('name', 'LIKE', '%'.$input.'%')->orWhere('overview', 'LIKE', '%'.$input.'%')->get();


        //Search query added to database
        $search = new Search();
        $search->title = $input;
        $search->save();

        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        return view('search', compact('results', 'categories', 'setting', 'tvResults'));

    }

    public function category($name) {

        $movies     = Movie::whereHas('categories', function($q) use($name) {$q->where('name', $name);})->get();

        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        if(!$movies) {
            return redirect('/');
        }

        $cname = $name;

        return view('category', compact('movies', 'cname', 'categories', 'setting'));
    }

    public function allMovies() {

        $movies     = Movie::orderby('id', 'desc')->paginate(18);

        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        $ad         = Ad::whereId(1)->first();

        return view('movies', compact('movies', 'categories', 'setting', 'ad'));

    }

    public function allTvshows() {

        $tvshows    = Tvshow::orderby('id', 'desc')->paginate(18);

        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        $ad         = Ad::whereId(1)->first();

        return view('tvshows', compact('tvshows', 'categories', 'setting', 'ad'));

    }


}
