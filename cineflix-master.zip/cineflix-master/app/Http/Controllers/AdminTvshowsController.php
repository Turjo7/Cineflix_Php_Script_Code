<?php

namespace App\Http\Controllers;

use App\Category;
use App\Http\Requests\AddSeasonRequest;
use App\Http\Requests\AddTvshowRequest;
use App\Setting;
use App\Tvshow;
use App\TvShowCredit;
use App\TvshowSeason;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Tmdb\Exception\TmdbApiException;
use Tmdb\Laravel\Facades\Tmdb;
use Tmdb\Model\Tv\Season;

class AdminTvshowsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {

        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        $tvshows    = Tvshow::orderBy('id', 'desc')->paginate(10);

        return view('admin.tvshows.index', compact('categories', 'setting', 'tvshows'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AddTvshowRequest $request)
    {
        $tvshow = new Tvshow();
        $tvshow->name = $request->name;
        $tvshow->overview = $request->overview;
        $tvshow->first_air_date = $request->first_air_date;
        $tvshow->homepage = $request->homepage;
        $tvshow->vote_average = $request->vote_average;
        $tvshow->trailer = $request->trailer;
        $tvshow->poster = $request->poster;
        $tvshow->tvshow_id = $request->tvshow_id;
        $tvshow->save();

        $tvshow->categories()->attach($request->categories_id);

        $credits = Tmdb::getTvApi()->getCredits($request->tmdbId);

        foreach($credits['cast'] as $cast) {

            $tvshowCredit = new TvShowCredit();

            $tvshowCredit->tvshow_id = $tvshow->id;
            $tvshowCredit->name = $cast['name'];
            $tvshowCredit->image = $cast['profile_path'];
            $tvshowCredit->character = $cast['character'];
            $tvshowCredit->save();

        }

        Session::flash('status', 'New Tv Show was added successfully!');

        return redirect('/admin/tvshows');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        try{

            $tvshow     = Tmdb::getTvApi()->getTvshow($id);

        } catch (TmdbApiException $e){

            if (TmdbApiException::STATUS_RESOURCE_NOT_FOUND == $e->getCode()) {

                Session::flash('status-warning', 'No tv show found for this ID!');

                return redirect()->route('admin.tvshows.index');

            }

        }

        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        $tvshow_id  = $id;

        return view('admin.tvshows.show', compact('tvshow', 'categories', 'setting', 'tvshow_id'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tvshow     = Tvshow::findOrFail($id);

        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        $seasons    = TvshowSeason::where('tvshow_id', $id)->orderBy('number', 'asc')->get();

        return view('admin.tvshows.edit', compact('tvshow', 'categories', 'setting', 'seasons'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(AddTvshowRequest $request, $id)
    {

        $input = $request->all();

        Tvshow::whereId($id)->first()->update($input);

        Session::flash('status', 'The TvShow ' . $input['name'] . ' was updated!');

        return redirect('/admin/tvshows');



    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $tvshow =  Tvshow::findOrFail($id);

        $tvshow->delete();

        Session::flash('status', 'A Tv Show was deleted!');

        return redirect('/admin/tvshows');

    }

    public function import(Request $request)
    {

        $input = $request->all();

        $id = $input['import'];

        return redirect()->route('admin.tvshows.show', $id);

    }

    public function addSeason(AddSeasonRequest $request) {

        $checkIfExists = TvshowSeason::where('number', $request->number)->where('tvshow_id', $request->tvshow_id)->first();

        if($checkIfExists == true) {

            Session::flash('status', 'This season is already added!');

            return redirect()->back();

        }

        $season = new TvshowSeason();

        $season->tvshow_id = $request->tvshow_id;

        $season->number = $request->number;

        $season->save();

        Session::flash('status', 'New season was added!');

        return redirect()->back();

    }

    public function search(Request $request) {

        $input = $request->q;

        $results = Tvshow::where('name', 'LIKE', '%'.$input.'%')->orWhere('overview', 'LIKE', '%'.$input.'%')->orderBy('id','desc')->paginate(10);

        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        return view('admin.tvshows.search', compact('results', 'categories', 'setting', 'input'));

    }

}
