<?php

namespace App\Http\Controllers;

use App\Category;
use App\Episode;
use App\Http\Requests\AddEpisodeRequest;
use App\Setting;
use App\Tvshow;
use App\TvshowSeason;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class AdminTvShowSeasonController extends Controller
{
    public function showSeason($slug, $number) {

        $tvshow = Tvshow::where('slug', $slug)->first();

        $episodes = Episode::where('tvshow_id', $tvshow->id)->where('season_id', $number)->get();

        $seasonNumber = $number;

        $categories = Category::orderBy('name')->get();

        $setting = Setting::whereId(1)->first();

        return view('admin.tvshows.season', compact('tvshow', 'episodes', 'seasonNumber', 'categories', 'setting'));

    }

    public function deleteSeason(Request $request) {

        TvshowSeason::where('tvshow_id', $request->tvshow_id)->where('number', $request->season)->first()->delete();

        Session::flash('status', 'A season was removed!');

        return redirect()->back();

    }

    public function editEpisode($slug, $number, $episodeNumber) {

        $tvshow = Tvshow::where('slug', $slug)->first();

        $episode = Episode::where('tvshow_id', $tvshow->id)->where('season_id', $number)->where('episode_number', $episodeNumber)->first();

        $categories = Category::orderBy('name')->get();

        $setting = Setting::whereId(1)->first();

        $seasonNumber = $number;

        $episodeNr = $episodeNumber;

        return view('admin.tvshows.episode', compact('tvshow', 'episode', 'categories', 'setting', 'seasonNumber', 'episodeNr'));

    }

    public function updateEpisode(AddEpisodeRequest $request) {

        $input = $request->all();

        Episode::whereId($input['episode_id'])->first()->update($input);

        Session::flash('status', 'Episode ' . $input['episode_number'] . ' was updated');

        return redirect()->back();

    }

    public function deleteEpisode($id) {

        Episode::whereId($id)->first()->delete();

        Session::flash('status', 'An episode was deleted!');

        return redirect('/admin/tvshows');
    }
}
