<?php

namespace App\Http\Controllers;

use App\Category;
use App\Favorite;
use App\Http\Requests\UpdatePasswordRequest;
use App\Http\Requests\UpdateUserEmailRequest;
use App\Movie;
use App\Setting;
use App\TvFavorite;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $user = Auth::user();

        $categories = Category::orderBy('name')->get();

        $setting    = Setting::whereId(1)->first();

        $favoriteTvShows = TvFavorite::where('user_id', $user->id)->orderBy('id', 'desc')->paginate(6);

        $favoriteMovies = Favorite::where('user_id', $user->id)->orderBy('id', 'desc')->paginate(6);

        return view('home', compact('categories', 'setting', 'favoriteTvShows', 'favoriteMovies', 'user'));
    }

    public function updateUserEmail(UpdateUserEmailRequest $request) {


        $user = Auth::user();

        $input = $request->all();

        User::whereId($user->id)->first()->update($input);

        Session::flash('status', 'User credentials changed successfully!');

        return redirect()->back();


    }

    public function updatePassword(UpdatePasswordRequest $request)
    {

        $input = $request->all();

        if (Auth::check()) {

            $current_password = Auth::user()->getAuthPassword();

            if (Hash::check($input['current-password'], $current_password)) {
                $user_id = Auth::user()->id;
                $obj_user = User::findOrFail($user_id);
                $obj_user->password = Hash::make($input['password']);;
                $obj_user->save();

                Session::flash('status', 'Your password was changed!');

                return redirect()->back();

            } else {

                Session::flash('status-warning', 'Enter correct current password');

                return redirect()->back();

            }

        }

    }
}
