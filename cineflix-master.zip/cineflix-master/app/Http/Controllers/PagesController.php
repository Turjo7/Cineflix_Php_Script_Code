<?php

namespace App\Http\Controllers;

use App\Category;
use App\Page;
use App\Setting;
use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function faq() {

        $categories = Category::orderBy('name')->get();

        $page       = Page::whereId(1)->first();

        $setting    = Setting::whereId(1)->first();

        return view('faq', compact('page', 'categories', 'setting'));
    }

    public function terms() {

        $categories = Category::orderBy('name')->get();

        $page       = Page::whereId(1)->first();

        $setting    = Setting::whereId(1)->first();

        return view('terms', compact('page', 'categories', 'setting'));
    }

    public function privacy() {

        $categories = Category::orderBy('name')->get();

        $page       = Page::whereId(1)->first();

        $setting    = Setting::whereId(1)->first();

        return view('privacy', compact('page', 'categories', 'setting'));
    }

    public function contact() {

        $categories = Category::orderBy('name')->get();

        $page       = Page::whereId(1)->first();

        $setting    = Setting::whereId(1)->first();

        return view('contact', compact('page', 'categories', 'setting'));
    }
}
