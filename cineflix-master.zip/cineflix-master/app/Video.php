<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Video extends Model
{

    protected $fillable = [

        'id',
        'name'
    ];

    public function movies(){
        return $this->belongsToMany('App\Movie');
    }
}
