<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TvshowSeason extends Model
{
    protected $table = 'tvshow_seasons';

    protected $fillable = [
        'tvshow_id',
        'number'
    ];

    public function tvshows() {
        return $this->belongsTo('App\Tvshow', 'tvshow_id');
    }

    public function episodes() {
        return $this->belongsToMany('App\Episode', 'episodes');
    }

}
