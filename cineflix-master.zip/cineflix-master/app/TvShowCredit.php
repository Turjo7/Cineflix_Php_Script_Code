<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TvShowCredit extends Model
{
    protected $fillable = [
        'tvshow_id',
        'name',
        'image',
        'character'
    ];

    public function tvshows() {
        return $this->belongsTo('App\Tvshow');
    }
}
