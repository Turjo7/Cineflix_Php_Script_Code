<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VideoPivot extends Model
{
    protected $table = 'movie_video';

    protected $fillable = [
        'id',
        'video_id',
        'movie_id'
    ];

    public function movies() {
        return $this->belongsToMany('App\Movie');
    }

    public function videos() {
        return $this->belongsToMany('App\Video', 'movie_video');
    }
}
