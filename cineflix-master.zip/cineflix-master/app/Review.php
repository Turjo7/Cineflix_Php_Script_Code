<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Review extends Model
{
    protected $fillable = [
        'movie_id',
        'is_active',
        'author',
        'body',
        'title'
    ];

    public function movies() {
        return $this->belongsTo('App\Movie', 'movie_id');
    }
}
