<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MovieCredit extends Model
{
    protected $fillable = [

        'movie_id',
        'name',
        'image',
        'character'

    ];

    public function movies() {
        return $this->belongsTo('App\Movie', 'movie_id');
    }
}
