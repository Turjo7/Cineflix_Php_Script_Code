<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Episode extends Model
{
    protected $table = 'episodes';

    protected $fillable = [

        'tvshow_id',
        'season_id',
        'episode_number',
        'title',
        'overview',
        'poster',
        'vote_average',
        'video'

    ];

    public function seasons() {
        return $this->belongsTo('App\TvshowSeason', 'season_id');
    }
}
