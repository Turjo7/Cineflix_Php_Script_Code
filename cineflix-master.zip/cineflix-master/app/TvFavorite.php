<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TvFavorite extends Model
{
    protected $fillable = [

        'user_id',
        'tvshow_title',
        'tvshow_slug',
        'tvshow_poster'

    ];

    public function users() {
        return $this->belongsTo('App\User');
    }
}
