<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CategoryTvShowPivot extends Model
{
    protected $table = 'category_tvshow';

    protected $fillable = [

        'category_id',
        'tvshow_id'

    ];

    public function tvshows() {
        return $this->belongsToMany('App\Tvshow');
    }

    public function categories() {
        return $this->belongsToMany('App\Category', 'category_tvshow');
    }
}
