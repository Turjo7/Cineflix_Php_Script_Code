<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;

class Tvshow extends Model
{
    use sluggable;

    public function sluggable()
    {
        return [
            'slug' => [
                'source' => 'name'
            ]
        ];
    }

    protected $fillable = [

        'name',
        'overview',
        'first_air_date',
        'homepage',
        'poster',
        'vote_average',
        'trailer',
        'slug'

    ];

    public function categories() {
        return $this->belongsToMany('App\Category');
    }

    public function seasons() {
        return $this->belongsToMany('App\TvshowSeason', 'tvshow_seasons');
    }
}
