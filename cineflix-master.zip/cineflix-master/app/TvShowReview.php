<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TvShowReview extends Model
{
    protected $fillable = [
        'tvshow_id',
        'is_active',
        'author',
        'body',
        'title'
    ];

    public function tvshows() {
        return $this->belongsTo('App\Tvshow', 'tvshow_id');
    }
}
