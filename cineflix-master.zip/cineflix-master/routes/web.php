<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'HomepageController@index')->name('homepage');

Auth::routes();

Route::get('logout', ['as' => 'logout', 'uses' => 'Auth\LoginController@logout']);

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/movie/{slug}','HomepageController@movie')->name('movie_detail');

Route::get('/tvshow/{slug}', 'HomepageController@tvshow')->name('tvshow_detail');

Route::get('/tvshow/{slug}/season-{number}', 'HomepageController@season')->name('season_detail');

Route::post('/movie/','ReviewsController@store')->name('MovieReviewStore');

Route::post('/tvshow/', 'TvShowReviewsController@store')->name('TvShowReviewController');

Route::get('/search', 'HomepageController@search')->name('search');

Route::get('/category/{name}', 'HomepageController@category')->name('category');

Route::get('/movies', 'HomepageController@allMovies')->name('movies');

Route::get('/tvshows', 'HomepageController@allTvshows')->name('tvshows');

Route::get('/password/reset', 'Auth\ResetPasswordController@index')->name('PasswordResetIndex');

Route::get('/faq', 'PagesController@faq')->name('faq');

Route::get('/terms', 'PagesController@terms')->name('terms');

Route::get('/privacy', 'PagesController@privacy')->name('privacy');

Route::get('/contact', 'PagesController@contact')->name('contact');

Route::group(['middleware'=>'auth'], function () {

    Route::post('/movie/favorite', 'MovieFavorites@store')->name('AddFavoriteMovie');

    Route::post('/tvshow/favorite', 'TvShowFavoritesController@store')->name('AddFavoriteTvShow');

    Route::post('/tvshow/favorite/remove', 'TvShowFavoritesController@destroy')->name('RemoveFavoriteTvShow');

    Route::post('/movie/favorite/remove', 'MovieFavorites@destroy')->name('RemoveFavoriteMovie');

    Route::post('/home/update/user', 'HomeController@updateUserEmail')->name('UpdateUserEmail');

    Route::post('home/update/user/password', 'HomeController@updatePassword')->name('UpdatePassword');

});

Route::group(['middleware'=>'admin'], function (){

    Route::post('/admin/movies/import', ['as'=>'import', 'uses' => 'AdminMoviesController@import']);

    Route::post('/admin/tvshows/import', ['as'=>'import', 'uses'=>'AdminTvshowsController@import']);

    Route::post('/admin/tvshows/addSeason', 'AdminTvshowsController@addSeason')->name('addSeason');

    Route::post('/admin/tvshows/deleteSeason', 'AdminTvShowSeasonController@deleteSeason')->name('deleteSeason');

    Route::post('/admin/tvshow/season/episode', 'EpisodeController@import')->name('import');

    Route::get('/admin/movies/search', 'AdminMoviesController@search')->name('search_movies');

    Route::get('/admin/tvshows/search', 'AdminTvshowsController@search')->name('search_tvshows');

    Route::get('/admin/users/search', 'AdminUsersController@search')->name('search_users');

    Route::get('/admin/tvshow/{tvshow}/season-{number}', 'AdminTvShowSeasonController@showSeason')->name('season_episodes');

    Route::get('/admin/tvshow/{slug}/season-{number}/episode-{episodeNumber}', 'AdminTvShowSeasonController@editEpisode')->name('edit_episode');

    Route::post('/admin/tvshow/episode/update', 'AdminTvShowSeasonController@updateEpisode')->name('updateEpisode');

    Route::get('/admin/tvshow/episode/delete={episode}', 'AdminTvShowSeasonController@deleteEpisode')->name('deleteEpisode');

    Route::resource('/admin/movies', 'AdminMoviesController')->names([
        'index'=>'admin.movies.index',
        'create'=>'admin.movies.create',
        'edit'=>'admin.movies.edit',
        'store'=>'admin.movies.store',
        'show'=>'admin.movies.show',
        'import'=>'admin.movies.import',
        'search'=>'admin.movies.search'
    ]);

    Route::resource('/admin/tvshows', 'AdminTvshowsController')->names([

        'index'=>'admin.tvshows.index',
        'create'=>'admin.tvshows.create',
        'edit'=>'admin.tvshows.edit',
        'store'=>'admin.tvshows.store',
        'show'=>'admin.tvshows.show',
        'import'=>'admin.tvshows.import',
        'search'=>'admin.tvshows.search'

    ]);

    Route::resource('/admin/episodes', 'EpisodeController')->names([

        'index'=>'admin.episodes.index',
        'edit'=>'admin.episodes.edit',
        'show'=>'admin.episodes.show',
        'store'=>'admin.episodes.store',
        'import'=>'admin.episodes.import'

    ]);

    Route::resource('/admin/categories', 'AdminCategoriesController')->names([
        'index'=>'admin.categories.index',
        'create'=>'admin.categories.create',
        'store'=>'admin.categories.store',
        'edit'=>'admin.categories.edit',
    ]);

    Route::resource('/admin/users', 'AdminUsersController')->names([
        'index'=>'admin.users.index',
        'create'=>'admin.users.create',
        'edit'=>'admin.users.edit'
    ]);

    Route::resource('/admin/reviews', 'AdminReviewController')->names([
        'index'=>'admin.reviews.index',
        'edit'=>'admin.reviews.edit'
    ]);

    Route::resource('/admin/tvshowreviews', 'AdminTvShowReviewController')->names([
        'index'=>'admin.tvshowreviews.index',
        'edit'=>'admin.tvshowreviews.edit'
    ]);

    Route::resource('/admin/searches', 'AdminSearchesController')->names([
        'index'=>'admin.searches.index'
    ]);

    Route::resource('/admin/settings', 'AdminSettingsController')->names([
        'index'=>'admin.settings.index'
    ]);

    Route::resource('/admin/pages', 'AdminPagesController')->names([
        'index'=>'admin.pages.index'
    ]);

    Route::resource('/admin/ads', 'AdminAdsController')->names([
        'index'=>'admin.ads.index'
    ]);

    Route::resource('/admin', 'AdminController');

});



